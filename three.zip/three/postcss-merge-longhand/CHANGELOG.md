# 2.0.2

* Fixes an issue where properties with the `initial` keyword were being merged
  (thanks to @holmari).

# 2.0.1

* Fixed a crash when the module was trying to retrieve declarations
  from a rule which contained comments in it.

# 2.0.0

* Upgraded to PostCSS 5.

# 1.0.2

* Fixes an issue where properties with the `inherit` keyword were being merged.

# 1.0.1

* Fixes an issue where calc values were being mangled.

# 1.0.0

* Initial release.

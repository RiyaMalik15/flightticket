package com.infy.model;

import java.time.LocalDate;

import com.infy.entity.CustomerEntity;

public class Customer {
	private Integer customerId;
	private String name;
	private Long phoneNumber;
	private LocalDate dob;
	private String state;
	private String district;
	private String gender;
	private String email;
	private String password;
	private String message;
	public Integer getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(Long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public LocalDate getDob() {
		return dob;
	}
	public void setDob(LocalDate dob) {
		this.dob = dob;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Customer() {}
	public Customer(CustomerEntity customer){
		this.customerId = customer.getCustomerId();
		this.name = customer.getName();
		this.phoneNumber = customer.getPhoneNumber();
		this.dob = customer.getDob();
		this.state = customer.getState();
		this.district = customer.getDistrict();
		this.gender= customer.getGender();
		this.email=customer.getEmail();
		this.password=customer.getPassword();
		this.message=customer.getMessage();
	} 
}
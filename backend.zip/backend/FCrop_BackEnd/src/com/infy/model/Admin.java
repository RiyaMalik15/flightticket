package com.infy.model;

import com.infy.entity.AdminEntity;

public class Admin{
	private String name;
	private String username;
	private String password;
	private String message;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
public Admin(){}
	
	public Admin(AdminEntity admin){
		this.setName(admin.getName());
		this.setUsername(admin.getUsername());
		this.setPassword(admin.getPassword());
		this.setMessage(admin.getMessage());
	}
}
package com.infy.model;

import com.infy.entity.ContactEntity;

public class Contact{
	private Integer MId;
	private Long phoneNumber;
	private String name;
	private String lname;
	private String message;
	
	
	public Integer getMId() {
		return MId;
	}
	public void setMId(Integer mId) {
		this.MId = mId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}

	
	public Long getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(Long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	public Contact(){}
	
	public Contact(ContactEntity entity){
		this.setMId(entity.getMId());
		this.setLname(entity.getLname());
		this.setPhoneNumber(entity.getPhoneNumber());
		this.setName(entity.getName());
		this.setMessage(entity.getMessage());
	}
	
}
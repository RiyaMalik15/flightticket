package com.infy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.FCropDAO;
import com.infy.model.Admin;
import com.infy.model.Contact;
import com.infy.model.Customer;

@Service("FCropService")
@Transactional(readOnly = true)
public class FCropImpl implements FCrop {
	
	@Autowired
	private FCropDAO dao;

	@Transactional(readOnly = false,propagation=Propagation.REQUIRES_NEW)
	@Override
	public Integer addCustomer(Customer customer) throws Exception {
		
		Integer CId = dao.addCustomer(customer);
		if (CId == null){
			throw new Exception();
		}
		return CId;
	}

	@Override
	@Transactional(readOnly = false,propagation=Propagation.REQUIRES_NEW)
	public Customer loginCustomer(Customer customer) throws Exception {
		
		Customer customer2 = dao.loginCustomer(customer);
		if (customer2 == null){
			throw new Exception("Service.LOGIN_FAILURE_PASS_MM");
		}
		return customer2;
	}
	
	@Override
	@Transactional(readOnly = false,propagation=Propagation.REQUIRES_NEW)
	public Customer getCustomerbyId(Integer cid) throws Exception {
		return dao.getCustomerbyId(cid);
	}

	@Override
	@Transactional(readOnly = false,propagation=Propagation.REQUIRES_NEW)
	public Integer addContactQuery(Contact contact) throws Exception {
		Integer MId = dao.addContactQuery(contact);
		if(MId == null){
			throw new Exception();
		}
		return MId;
	}	

	@Override
	@Transactional(readOnly = false,propagation=Propagation.REQUIRES_NEW)
	public Admin loginAdmin(Admin admin) throws Exception {
		
		Admin admin2 = dao.loginAdmin(admin);
		if (admin2 == null){
			throw new Exception("Service.LOGIN_FAILURE_PASS_MM");
		}
		return admin2;
	}

	@Override
	public List<Customer> getallCustomers() throws Exception {
		
		return dao.getallEmployees();
	}

	@Override
	public List<Contact> getallMessages() throws Exception {
		
		return dao.getallMessages();
	}

	@Override
	public Customer updateCustomer(Customer customer) throws Exception {
		return dao.updateCustomer(customer);
	}

	
}

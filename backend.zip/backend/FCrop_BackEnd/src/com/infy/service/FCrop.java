package com.infy.service;

import java.util.List;

import com.infy.model.Admin;
import com.infy.model.Contact;
import com.infy.model.Customer;

public interface FCrop {
	
	public Integer addCustomer(Customer customer) throws Exception;
	
	public Customer loginCustomer(Customer customer) throws Exception;

	public Customer getCustomerbyId(Integer cid) throws Exception;
	
	public Integer addContactQuery (Contact contact) throws Exception;

	public Admin loginAdmin(Admin admin) throws Exception;
	
	public List<Customer> getallCustomers() throws Exception;
	
	public List<Contact> getallMessages() throws Exception;

	public Customer updateCustomer(Customer customer) throws Exception;
}

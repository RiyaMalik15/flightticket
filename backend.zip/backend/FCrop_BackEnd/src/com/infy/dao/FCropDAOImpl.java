package com.infy.dao;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.entity.AdminEntity;
import com.infy.entity.ContactEntity;
import com.infy.entity.CustomerEntity;
import com.infy.model.Admin;
import com.infy.model.Contact;
import com.infy.model.Customer;

@Repository("dao")
public class FCropDAOImpl implements FCropDAO {
	
	@Autowired
	SessionFactory sessionFactory;

	@Override
	public Integer addCustomer(Customer customer) throws Exception {
		
		Session session = sessionFactory.getCurrentSession();
		CustomerEntity customerEntity = new CustomerEntity(customer);
		return (Integer) session.save(customerEntity);
	}

	@Override
	public Customer loginCustomer(Customer customer) throws Exception {
		Customer customer2 = null;
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<CustomerEntity> criteriaQuery = builder.createQuery(CustomerEntity.class);
		Root<CustomerEntity> root = criteriaQuery.from(CustomerEntity.class);
		criteriaQuery.select(root);
		criteriaQuery.where(builder.and(builder.equal(root.get("phoneNumber"), customer.getPhoneNumber()),builder.equal(root.get("password"), customer.getPassword())));
		CustomerEntity customerEntity = session.createQuery(criteriaQuery).uniqueResult();
		if (customerEntity != null){
			customer2 = new Customer(customerEntity);
		}
		return customer2;
	}
	
	@Override
	public Customer getCustomerbyId(Integer cid) throws Exception {
		Session session=sessionFactory.getCurrentSession();
		CustomerEntity ce=session.get(CustomerEntity.class, cid);
		if(ce==null)
		{
			throw new Exception();
		}
		Customer customer=new Customer(ce);
		return customer;
	}

	@Override
	public Integer addContactQuery(Contact contact) throws Exception {
		
		Session session = sessionFactory.getCurrentSession();
		ContactEntity contactEntity = new ContactEntity(contact);
		return (Integer) session.save(contactEntity);
	}

	@Override
	public Admin loginAdmin(Admin admin) throws Exception {
		Admin admin2 = null;
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<AdminEntity> criteriaQuery = builder.createQuery(AdminEntity.class);
		Root<AdminEntity> root = criteriaQuery.from(AdminEntity.class);
		criteriaQuery.select(root);
		criteriaQuery.where(builder.and(builder.equal(root.get("username"), admin.getUsername()),builder.equal(root.get("password"), admin.getPassword())));
		AdminEntity adminEntity = session.createQuery(criteriaQuery).uniqueResult();
		if (adminEntity != null){
			admin2 = new Admin(adminEntity);
		}
		return admin2;
	}

	@Override
	public List<Customer> getallEmployees() throws Exception {
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<CustomerEntity> criteriaQuery= builder.createQuery(CustomerEntity.class);

		Root<CustomerEntity> root = criteriaQuery.from(CustomerEntity.class);
		criteriaQuery.select(root);
		
		List<Customer> customers=new ArrayList<>();
		List<CustomerEntity> ce=session.createQuery(criteriaQuery).getResultList();
		
	for (CustomerEntity customerEntity : ce) {
			
			Customer cust=new Customer(customerEntity);
			customers.add(cust);
		}
		return customers;
	}

	@Override
	public List<Contact> getallMessages() throws Exception {
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<ContactEntity> criteriaQuery= builder.createQuery(ContactEntity.class);

		Root<ContactEntity> root = criteriaQuery.from(ContactEntity.class);
		criteriaQuery.select(root);
		
		List<Contact> queries=new ArrayList<>();
		List<ContactEntity> ce=session.createQuery(criteriaQuery).getResultList();
		
		for (ContactEntity contactEntity : ce) {
			
			Contact mess=new Contact(contactEntity);
			queries.add(mess);
		}
		return queries;
	}
	@Override
	public Customer updateCustomer(Customer customer) throws Exception {
		
		
		Session session = sessionFactory.getCurrentSession();
		CustomerEntity ee=session.get(CustomerEntity.class,customer.getCustomerId());
		if(ee==null)
		{
			throw new Exception();
		}
		ee.setDob(customer.getDob());
		ee.setName(customer.getName());
		ee.setPhoneNumber(customer.getPhoneNumber());
		session.save(ee);
		return new Customer(ee);
		
	}

}

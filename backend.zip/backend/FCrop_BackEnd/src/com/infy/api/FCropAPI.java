package com.infy.api;

import java.util.ArrayList;
import java.util.List;

import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infy.model.Admin;
import com.infy.model.Contact;
import com.infy.model.Customer;
import com.infy.service.FCrop;
import com.infy.service.FCropImpl;
import com.infy.utility.ContextFactory;



@RestController
@CrossOrigin
@RequestMapping(value="FCrop")
public class FCropAPI {
	
	static FCrop service = ContextFactory.getContext().getBean(FCropImpl.class);
	static Environment en=ContextFactory.getContext().getEnvironment();
	
	
	@PostMapping("addCustomer")
	public ResponseEntity<Customer> addCustomer(@RequestBody Customer customer){
		ResponseEntity<Customer> responseEntity = null;
		Integer CId = null;
		
		try{
			CId = service.addCustomer(customer);
			customer.setCustomerId(CId);
			responseEntity =new ResponseEntity<>(customer,HttpStatus.OK);
		}catch(Exception e){
			String error = en.getProperty(e.getMessage());
			Customer cst = new Customer();
			cst.setMessage(error);
			responseEntity = new ResponseEntity<Customer>(cst,HttpStatus.BAD_REQUEST);
		}
		return responseEntity;
	}
	
	@PostMapping("loginCustomer")
	public ResponseEntity<Customer> loginCustomer(@RequestBody Customer customer){
		ResponseEntity<Customer> responseEntity = null;
		Customer cst = null;
		
		try{
			cst = service.loginCustomer(customer);
			responseEntity =new ResponseEntity<>(cst,HttpStatus.OK);
		}catch(Exception e){
			String error = en.getProperty(e.getMessage());
			Customer cst1 = new Customer();
			cst1.setMessage(error);
			responseEntity = new ResponseEntity<Customer>(cst1,HttpStatus.BAD_REQUEST);
		}
		return responseEntity;
	}
	
	@GetMapping("getCustomerById/{cid}")
	public ResponseEntity<Customer> getEmployeeById(@PathVariable("cid") Integer cid)
	{
		ResponseEntity<Customer> res=null;
		Customer cust=null;
		try{
			cust=service.getCustomerbyId(cid);
			res=new ResponseEntity<>(cust,HttpStatus.OK);
		}
		catch(Exception e)
		{
			String error = en.getProperty(e.getMessage());
			cust=new Customer();
			cust.setMessage(error);
			res = new ResponseEntity<>(cust,HttpStatus.BAD_REQUEST);
			
		}
		return res;
	}
	
	@PostMapping("addQuery")
	public ResponseEntity<Contact> addQuery(@RequestBody Contact contact){
		ResponseEntity<Contact> responseEntity = null;
		Integer MId = null;
		
		try{
			MId = service.addContactQuery(contact);
			contact.setMId(MId);
			responseEntity =new ResponseEntity<>(contact,HttpStatus.OK);
		}catch(Exception e){
			String error = en.getProperty(e.getMessage());
			Contact cnt = new Contact();
			cnt.setMessage(error);
			responseEntity = new ResponseEntity<Contact>(cnt,HttpStatus.BAD_REQUEST);
		}
		return responseEntity;
	}
	
	@PostMapping("loginAdmin")
	public ResponseEntity<Admin> loginAdmin(@RequestBody Admin admin){
		ResponseEntity<Admin> responseEntity = null;
		Admin adm = null;
		
		try{
			adm = service.loginAdmin(admin);
			responseEntity =new ResponseEntity<>(adm,HttpStatus.OK);
		}catch(Exception e){
			String error = en.getProperty(e.getMessage());
			Admin adm1 = new Admin();
			adm1.setMessage(error);
			responseEntity = new ResponseEntity<Admin>(adm1,HttpStatus.BAD_REQUEST);
		}
		return responseEntity;
	}
	
	@GetMapping("getallCustomers")
	public ResponseEntity<List<Customer>> getallCustomers()
	{
		ResponseEntity<List<Customer>> res=null;
		List<Customer> customers=null;
		Customer customer=null;
		try{
			customers=service.getallCustomers();
			res=new ResponseEntity<>(customers,HttpStatus.OK);
		}
		catch(Exception e)
		{
			String error = en.getProperty(e.getMessage());
			customer=new Customer();
			customer.setMessage(error);
			customers=new ArrayList<Customer>();
			customers.add(customer);
			res = new ResponseEntity<>(customers,HttpStatus.BAD_REQUEST);
			
		}
		return res;
		
	}
	
	@GetMapping("getallMessages")
	public ResponseEntity<List<Contact>> getallMessages()
	{
		ResponseEntity<List<Contact>> res=null;
		List<Contact> contacts=null;
		Contact contact=null;
		try{
			contacts=service.getallMessages();
			res=new ResponseEntity<>(contacts,HttpStatus.OK);
		}
		catch(Exception e)
		{
			String error = en.getProperty(e.getMessage());
			contact=new Contact();
			contact.setMessage(error);
			contacts=new ArrayList<Contact>();
			contacts.add(contact);
			res = new ResponseEntity<>(contacts,HttpStatus.BAD_REQUEST);
			
		}
		return res;
		
	}
	@PostMapping("updateCustomer")
	public ResponseEntity<Customer> updateCustomer(@RequestBody Customer customer)
	{
		
		ResponseEntity<Customer> res=null;
		Customer cus=null;
		try{
			cus=service.updateCustomer(customer);
			res=new ResponseEntity<>(cus,HttpStatus.OK);
		}
		catch(Exception e)
		{
			String error = en.getProperty(e.getMessage());
			cus=new Customer();
			cus.setMessage(error);
			res = new ResponseEntity<>(cus,HttpStatus.BAD_REQUEST);
			
		}
		return res;
		
	}
	
	
	
	
}

package com.infy.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.infy.model.Admin;


@Entity
@Table(name = "AdminDetails")
public class AdminEntity{
	@Id
	private String name;
	private String username;
	private String password;
	private String message;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	public AdminEntity(){}
	
	public AdminEntity(Admin admin){
		this.setName(admin.getName());
		this.setUsername(admin.getUsername());
		this.setPassword(admin.getPassword());
		this.setMessage(admin.getMessage());
	}
}
package com.infy.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.infy.model.Contact;

@Entity
@Table(name = "ContactForm")
@GenericGenerator(name = "gen", strategy = "increment")
public class ContactEntity {
	@Id
	@GeneratedValue(generator= "gen")
	private Integer MId;
	private String name;
	private Long phoneNumber;
	private String lname;
	private String message;
	
	
	public Integer getMId() {
		return MId;
	}
	public void setMId(Integer mId) {
		this.MId = mId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	
	public Long getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(Long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
public ContactEntity(){}
	
	public ContactEntity(Contact entity){
		this.setMId(entity.getMId());
		this.setPhoneNumber(entity.getPhoneNumber());
		this.setLname(entity.getLname());
		this.setName(entity.getName());
		this.setMessage(entity.getMessage());
	}
}
CREATE TABLE mytable(
   District_Code VARCHAR(4) NOT NULL PRIMARY KEY
  ,State         VARCHAR(9) NOT NULL
  ,District_Name VARCHAR(16) NOT NULL
);
INSERT INTO mytable(District_Code,State,District_Name) VALUES ('KA1','Karnataka','BELGAUM');
INSERT INTO mytable(District_Code,State,District_Name) VALUES ('KA2','Karnataka','BAGALKOT');
INSERT INTO mytable(District_Code,State,District_Name) VALUES ('KA3','Karnataka','BIJAPUR');
INSERT INTO mytable(District_Code,State,District_Name) VALUES ('KA4','Karnataka','GULBARGA');
INSERT INTO mytable(District_Code,State,District_Name) VALUES ('KA5','Karnataka','BIDAR');
INSERT INTO mytable(District_Code,State,District_Name) VALUES ('KA6','Karnataka','RAICHUR');
INSERT INTO mytable(District_Code,State,District_Name) VALUES ('KA7','Karnataka','KOPPAL');
INSERT INTO mytable(District_Code,State,District_Name) VALUES ('KA8','Karnataka','GADAG');
INSERT INTO mytable(District_Code,State,District_Name) VALUES ('KA9','Karnataka','DHARWAD');
INSERT INTO mytable(District_Code,State,District_Name) VALUES ('KA10','Karnataka','UTTARA_KANNADA');
INSERT INTO mytable(District_Code,State,District_Name) VALUES ('KA11','Karnataka','HAVERI');
INSERT INTO mytable(District_Code,State,District_Name) VALUES ('KA12','Karnataka','BELLARY');
INSERT INTO mytable(District_Code,State,District_Name) VALUES ('KA13','Karnataka','CHITRADURGA');
INSERT INTO mytable(District_Code,State,District_Name) VALUES ('KA14','Karnataka','DAVANGERE');
INSERT INTO mytable(District_Code,State,District_Name) VALUES ('KA15','Karnataka','SHIMOGA');
INSERT INTO mytable(District_Code,State,District_Name) VALUES ('KA16','Karnataka','UDUPI');
INSERT INTO mytable(District_Code,State,District_Name) VALUES ('KA17','Karnataka','CHIKMAGALUR');
INSERT INTO mytable(District_Code,State,District_Name) VALUES ('KA18','Karnataka','TUMKUR');
INSERT INTO mytable(District_Code,State,District_Name) VALUES ('KA19','Karnataka','CHIKKABALLAPUR');
INSERT INTO mytable(District_Code,State,District_Name) VALUES ('KA20','Karnataka','KOLAR');
INSERT INTO mytable(District_Code,State,District_Name) VALUES ('KA21','Karnataka','BANGALORE');
INSERT INTO mytable(District_Code,State,District_Name) VALUES ('KA22','Karnataka','BANGALORE_RURAL');
INSERT INTO mytable(District_Code,State,District_Name) VALUES ('KA23','Karnataka','RAMANAGARAM');
INSERT INTO mytable(District_Code,State,District_Name) VALUES ('KA24','Karnataka','MANDYA');
INSERT INTO mytable(District_Code,State,District_Name) VALUES ('KA25','Karnataka','HASSAN');
INSERT INTO mytable(District_Code,State,District_Name) VALUES ('KA26','Karnataka','DAKSHINA_KANNADA');
INSERT INTO mytable(District_Code,State,District_Name) VALUES ('KA27','Karnataka','KODAGU');
INSERT INTO mytable(District_Code,State,District_Name) VALUES ('KA28','Karnataka','MYSORE');
INSERT INTO mytable(District_Code,State,District_Name) VALUES ('KA29','Karnataka','CHAMARAJNAGAR');
INSERT INTO mytable(District_Code,State,District_Name) VALUES ('KA30','Karnataka','YADGIR');

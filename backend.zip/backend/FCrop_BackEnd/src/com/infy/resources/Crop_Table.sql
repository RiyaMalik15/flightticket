CREATE TABLE mytable(
   Crop_code        VARCHAR(3) NOT NULL PRIMARY KEY
  ,Crop_name        VARCHAR(13) NOT NULL
  ,Time_reqMonths   INTEGER  NOT NULL
);
INSERT INTO mytable(Crop_code,Crop_name,Time_reqMonths) VALUES ('C1','Tur',7);
INSERT INTO mytable(Crop_code,Crop_name,Time_reqMonths) VALUES ('C2','Bajra',4);
INSERT INTO mytable(Crop_code,Crop_name,Time_reqMonths) VALUES ('C3','Cotton',8);
INSERT INTO mytable(Crop_code,Crop_name,Time_reqMonths) VALUES ('C4','Groundnut',4);
INSERT INTO mytable(Crop_code,Crop_name,Time_reqMonths) VALUES ('C5','Jowar',5);
INSERT INTO mytable(Crop_code,Crop_name,Time_reqMonths) VALUES ('C6','Maize',5);
INSERT INTO mytable(Crop_code,Crop_name,Time_reqMonths) VALUES ('C7','Onion',2);
INSERT INTO mytable(Crop_code,Crop_name,Time_reqMonths) VALUES ('C8','Mustard',2);
INSERT INTO mytable(Crop_code,Crop_name,Time_reqMonths) VALUES ('C9','Rice',6);
INSERT INTO mytable(Crop_code,Crop_name,Time_reqMonths) VALUES ('C10','Small Millets',4);
INSERT INTO mytable(Crop_code,Crop_name,Time_reqMonths) VALUES ('C11','Sunflower',4);
INSERT INTO mytable(Crop_code,Crop_name,Time_reqMonths) VALUES ('C12','Wheat',4);
INSERT INTO mytable(Crop_code,Crop_name,Time_reqMonths) VALUES ('C13','Coconut',120);
INSERT INTO mytable(Crop_code,Crop_name,Time_reqMonths) VALUES ('C14','Castor Seed',6);
INSERT INTO mytable(Crop_code,Crop_name,Time_reqMonths) VALUES ('C15','Sesamum',4);
INSERT INTO mytable(Crop_code,Crop_name,Time_reqMonths) VALUES ('C16','Garlic',2);
INSERT INTO mytable(Crop_code,Crop_name,Time_reqMonths) VALUES ('C17','Linseed',4);
INSERT INTO mytable(Crop_code,Crop_name,Time_reqMonths) VALUES ('C18','Sugarcane',4);
INSERT INTO mytable(Crop_code,Crop_name,Time_reqMonths) VALUES ('C19','Brinjal',4);
INSERT INTO mytable(Crop_code,Crop_name,Time_reqMonths) VALUES ('C20','Grapes',16);
INSERT INTO mytable(Crop_code,Crop_name,Time_reqMonths) VALUES ('C21','Papaya',7);
INSERT INTO mytable(Crop_code,Crop_name,Time_reqMonths) VALUES ('C22','Cashewnut',16);
INSERT INTO mytable(Crop_code,Crop_name,Time_reqMonths) VALUES ('C23','Ragi',5);
INSERT INTO mytable(Crop_code,Crop_name,Time_reqMonths) VALUES ('C24','Tobacco',5);
INSERT INTO mytable(Crop_code,Crop_name,Time_reqMonths) VALUES ('C25','Potato',4);

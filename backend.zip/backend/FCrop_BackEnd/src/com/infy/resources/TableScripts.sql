drop table CustomerDetails;
drop table ContactForm;
drop table AdminDetails;

CREATE TABLE CustomerDetails(
customerId Number(3) PRIMARY KEY,
name VARCHAR2(25),
phoneNumber Number(10) unique NOT NULL,
dob DATE,
state VARCHAR2(25),
district VARCHAR2(25),
gender VARCHAR2(2),
email VARCHAR2(25) unique,
password VARCHAR2(25) NOT NULL,
message VARCHAR2(25)
);

INSERT INTO CustomerDetails VALUES(101,'vaibhav',8881274608,null,'Karnatka','Mysore','M','vaibhav@gmail.com','Srm123#',null);
INSERT INTO CustomerDetails VALUES(102, 'pushpanjali',8449411118, null,'Karnatka','Mysore','F','pushpanjali@gmail.com','Graphic123#',null);


CREATE table ContactForm(
Mid number(4) primary key,
name VARCHAR2(25),
lname VARCHAR2(20),
phoneNumber Number(10),
message VARCHAR2(75)
);

insert into ContactForm values(1001,'vaibhav','gupta',8449411118,'Hello bro..');

CREATE table AdminDetails(
adminId Number(3) PRIMARY KEY,
name VARCHAR2(25) not null,
username varchar2(11) unique not null,
password varchar2(15) not null,
message varchar2(25)
);

insert into AdminDetails values(701,'shagun','shagunadm', 'Graphic123#', null);


select * from AdminDetails;
Select * from CustomerDetails;
Select * from ContactForm;
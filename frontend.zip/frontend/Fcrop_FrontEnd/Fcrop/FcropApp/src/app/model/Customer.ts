export class Customer{
    customerId : number;
	name: string;
	phoneNumber : number;
	dob: Date;
	state:string;
	district:string;
	gender:string;
	email:string;
	password:string;
    message:string;
}
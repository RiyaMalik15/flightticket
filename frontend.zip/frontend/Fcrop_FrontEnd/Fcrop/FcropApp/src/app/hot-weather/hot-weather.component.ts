import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hot-weather',
  templateUrl: './hot-weather.component.html',
  styleUrls: ['./hot-weather.component.css']
})
export class HotWeatherComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

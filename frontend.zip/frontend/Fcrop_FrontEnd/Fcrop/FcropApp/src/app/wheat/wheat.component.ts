import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wheat',
  templateUrl: './wheat.component.html',
  styleUrls: ['./wheat.component.css']
})
export class WheatComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

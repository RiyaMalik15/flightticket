import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-spring-season',
  templateUrl: './spring-season.component.html',
  styleUrls: ['./spring-season.component.css']
})
export class SpringSeasonComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

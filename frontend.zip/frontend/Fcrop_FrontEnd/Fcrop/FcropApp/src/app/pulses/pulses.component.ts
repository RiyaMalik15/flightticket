import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pulses',
  templateUrl: './pulses.component.html',
  styleUrls: ['./pulses.component.css']
})
export class PulsesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

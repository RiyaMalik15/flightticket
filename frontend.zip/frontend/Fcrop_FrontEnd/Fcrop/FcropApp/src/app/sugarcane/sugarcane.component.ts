import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sugarcane',
  templateUrl: './sugarcane.component.html',
  styleUrls: ['./sugarcane.component.css']
})
export class SugarcaneComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

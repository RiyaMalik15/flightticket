import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cold-weather',
  templateUrl: './cold-weather.component.html',
  styleUrls: ['./cold-weather.component.css']
})
export class ColdWeatherComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agriculture',
  templateUrl: './agriculture.component.html',
  styleUrls: ['./agriculture.component.css']
})
export class AgricultureComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-maize',
  templateUrl: './maize.component.html',
  styleUrls: ['./maize.component.css']
})
export class MaizeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

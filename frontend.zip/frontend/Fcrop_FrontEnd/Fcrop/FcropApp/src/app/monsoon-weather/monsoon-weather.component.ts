import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-monsoon-weather',
  templateUrl: './monsoon-weather.component.html',
  styleUrls: ['./monsoon-weather.component.css']
})
export class MonsoonWeatherComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { FCropServiceService} from '../fcrop-service.service';
import { FcropValidator } from '../Fcrop-Validator';
import { Customer } from '../model/Customer';
import { DatePipe, Location } from '@angular/common';
@Component({
  selector: 'app-update-customer',
  templateUrl: './update-customer.component.html',
  styleUrls: ['./update-customer.component.css']
})
export class UpdateCustomerComponent implements OnInit {
  FcropValidator: any;
  errorMessage: string;
  successMessage : string;
  customer:Customer;
  signUpForm : FormGroup;
  constructor(private fb : FormBuilder, private service : FCropServiceService,private loc:Location) { }

  ngOnInit() {
    this.signUpForm = this.fb.group({
      name : ['',[Validators.required]],
      dob : ['',[Validators.required]],
      phone_Number : ['',[Validators.required, Validators.pattern("[0-9]{10}")]]
    })

    this.signUpForm.controls.name.setValue(this.customer.name);
    this.signUpForm.controls.phone_Number.setValue(this.customer.phoneNumber)
    this.customer = JSON.parse(sessionStorage.getItem("customer"));
  }



  updateCustomer()
  {
    this.customer.name=this.signUpForm.controls.name.value;
    this.customer.dob=this.signUpForm.controls.dob.value;
    this.customer.phoneNumber=this.signUpForm.controls.phone_Number.value;
    
    this.service.updateCustomer(this.customer)
    .then((res)=>{
      
      this.customer=res;
      sessionStorage.setItem("customer",JSON.stringify(this.customer));
      console.log(this.customer);
      console.log("hello this is anand");
      alert("your values are updated");
      this.loc.back();
    })
    .catch(err=>this.errorMessage=err.message);
  }
 
}
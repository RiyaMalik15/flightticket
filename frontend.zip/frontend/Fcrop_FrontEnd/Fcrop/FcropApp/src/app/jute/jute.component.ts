import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-jute',
  templateUrl: './jute.component.html',
  styleUrls: ['./jute.component.css']
})
export class JuteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { FormGroup } from '@angular/forms/src/model';
import { Validators } from '@angular/forms';
import { element } from 'protractor';
import { customValidator } from '../validator';
import { AccessApiService } from '../access-api.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  errorMessage: string;
  successMessage : string;
  status=false;
  signUpForm : FormGroup;
  constructor(private fb : FormBuilder, private service : AccessApiService) { }

  ngOnInit() {
    this.signUpForm = this.fb.group({
      name : ['',[Validators.required]],
      dob : ['',[Validators.required]],
      password : ['',[Validators.required,customValidator.checkpassword]],
      re_Pass : ['',[Validators.required,customValidator.checkpassword]],
      email :['',[Validators.required, Validators.email]],
      phone_Number : ['',[Validators.required, Validators.pattern("[0-9]{10}")]]
      // area_Of_Intrest : ['',[Validators.required]]   <-- edit in phase 2
    })
  }

  check(){
    if(this.signUpForm.controls.password.value==this.signUpForm.controls.re_Pass.value){
      this.status=true;
    }
    else{
      this.status=false;
    }
  }


  addEmployee(){
    this.errorMessage=null;
    this.successMessage=null;
    this.service.addEmployee(this.signUpForm.value).
    then(res => this.successMessage = res.message).
    catch(err => this.errorMessage = err.message)
  }

}

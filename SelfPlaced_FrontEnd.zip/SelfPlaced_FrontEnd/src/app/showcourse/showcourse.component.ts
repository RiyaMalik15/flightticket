import { Component, OnInit } from '@angular/core';
import { Course } from '../model/Course';
import { AccessApiService } from '../access-api.service';

@Component({
  selector: 'app-showcourse',
  templateUrl: './showcourse.component.html',
  styleUrls: ['./showcourse.component.css']
})
export class ShowcourseComponent implements OnInit {

  course:Course[];
  message;

  constructor(private ser:AccessApiService) { }

  ngOnInit() {
    
    this.ser.getallCourses()
    .then(res=>this.course=res)
    .catch(err=>this.message=err[0].message);
    
  }

}

import { Component, OnInit } from '@angular/core';
import { Employee } from '../model/Employee';
import { Course } from '../model/Course';
import { FormBuilder } from '@angular/forms';
import { AccessApiService } from '../access-api.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-certificate',
  templateUrl: './certificate.component.html',
  styleUrls: ['./certificate.component.css']
})
export class CertificateComponent implements OnInit {

constructor(private fb : FormBuilder, private service : AccessApiService,private route:Router) { }

status=false;
url=""
employee:Employee;
courses:Course[];

  ngOnInit() {

    this.employee=JSON.parse(sessionStorage.getItem("employee"));
    this.service.getCompletedCourses(this.employee.empid)
    .then(res=>this.courses=res)
    .catch(err=>err)  

}

generateCertificate(empid,courseid)
{
  this.url="";
  this.status=true;
    this.service.generateCertificate(empid,courseid)
    .then(res=>{
      this.url=res.message;
      
    })
    .catch(err=>err)
}

getUrl(url)
{
  return url;
}

}

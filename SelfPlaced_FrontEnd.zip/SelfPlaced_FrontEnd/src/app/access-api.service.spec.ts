import { TestBed, inject } from '@angular/core/testing';

import { AccessApiService } from './access-api.service';

describe('AccessApiService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AccessApiService]
    });
  });

  it('should be created', inject([AccessApiService], (service: AccessApiService) => {
    expect(service).toBeTruthy();
  }));
});

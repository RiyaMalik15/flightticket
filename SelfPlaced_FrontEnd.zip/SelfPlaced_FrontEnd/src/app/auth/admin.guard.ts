import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class AdminGuard implements CanActivate {
  canActivate(): boolean {
    
    var str=prompt("Please enter your Password", "");
    if(str=="admin123")
      return true;
    else
    return false;
  }
}

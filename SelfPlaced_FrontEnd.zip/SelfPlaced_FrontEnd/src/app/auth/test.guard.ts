import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { CanDeactivate } from '@angular/router/src/interfaces';
import { TestComponent } from '../test/test.component';

@Injectable()
export class TestGuard implements CanDeactivate<TestComponent> {
  
 
  canDeactivate(component: TestComponent, 
    route: ActivatedRouteSnapshot, 
    state: RouterStateSnapshot) 
  {
   if(component.status)
   {
     alert("Submit Test First")
     return false;
   }
   else
   return true;  
  }
}

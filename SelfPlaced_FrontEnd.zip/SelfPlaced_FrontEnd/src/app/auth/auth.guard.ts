import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { AccessApiService } from '../access-api.service';
import { CanActivateChild, CanDeactivate } from '@angular/router/src/interfaces';
import { Employee } from '../model/Employee';

@Injectable()
export class AuthGuard implements CanActivate,CanDeactivate<any>{
  employee:Employee;

  constructor(private ser:AccessApiService,private router:Router)
  {
   
  }
  canActivate() {
    
   
    this.employee=JSON.parse(sessionStorage.getItem("employee"))
    if(!this.employee)
    {
       return false;
    }
    else
      return true;
   
  }
  canDeactivate()
  {
    sessionStorage.clear();
    this.ser.isUserLoggedin=false;
    return true;
  }
 

}

import { Injectable } from '@angular/core';
import { Http} from '@angular/http';
import 'rxjs/add/operator/toPromise';
import { Employee } from './model/Employee';
import { Feedback } from './model/Feedback';
import { Course } from './model/Course';
import { Question_Bank } from './model/Question_Bank';
import { EmployeeCourse } from './model/EmployeeCourse';

@Injectable()
export class AccessApiService {

   open="open";
   password="password";
   isUserLoggedin=false;

  constructor(private http:Http) { }

  addEmployee(data):Promise<any>{
    return this.http.post('http://localhost:3333/SelfPaced_BackEnd/SelfPaced/addEmployee',data).
    toPromise().
    then(res=>res.json()).
    catch(this.errorHandler)
  }

  addFeedback(data):Promise<any>{
    return this.http.post('http://localhost:3333/SelfPaced_BackEnd/SelfPaced/addFeedback',data).
    toPromise().
    then(res=>res.json()).
    catch(this.errorHandler)
  }

  courseAllocation(courseid,empid):Promise<any>{
    return this.http.get('http://localhost:3333/SelfPaced_BackEnd/SelfPaced/courseAllocation/'+courseid+'/'+empid).
    toPromise().
    then(res=>res.json()).
    catch(this.errorHandler)
  }

  calculateBadge(empid):Promise<any>{
    return this.http.get('http://localhost:3333/SelfPaced_BackEnd/SelfPaced/calculateBadge/'+empid).
    toPromise().
    then(res=>res.json()).
    catch(this.errorHandler)
  }

  loginEmployee(data):Promise<any>{

    return this.http.post('http://localhost:3333/SelfPaced_BackEnd/SelfPaced/loginEmployee',data).
    toPromise().
    then(res=>res.json()).
    catch(this.errorHandler)
  }

  getEmployeeById(empid):Promise<any>{

    return this.http.get('http://localhost:3333/SelfPaced_BackEnd/SelfPaced/getEmployeeById/'+empid).
    toPromise().
    then(res=> res.json()) 
    .catch(this.errorHandler)
  }



  check_details(data)
  {

    return this.http.post('http://localhost:3333/SelfPaced_BackEnd/SelfPaced/check_details',data).
    toPromise().
    then(res=>res.json()).
    catch(this.errorHandler)
   
    
  }

  change_password(data){

    return this.http.post('http://localhost:3333/SelfPaced_BackEnd/SelfPaced/change_password',data).
    toPromise().
    then(res=>res.toString()).
    catch(this.errorHandler)

  }


  updateEmployee(data){
  
    return this.http.post('http://localhost:3333/SelfPaced_BackEnd/SelfPaced/updateEmployee',data).
    toPromise().
    then(res=>res.json()).
    catch(this.errorHandler)

  }

  getallEmployees()
  {
    return this.http.get('http://localhost:3333/SelfPaced_BackEnd/SelfPaced/getallEmployees').
    toPromise().
    then(res=>res.json() as Employee[]).
    catch(this.errorHandler)


  }

  getallFeedbacks()
  {
    return this.http.get('http://localhost:3333/SelfPaced_BackEnd/SelfPaced/getallFeedbacks').
    toPromise().
    then(res=>res.json() as Feedback[]
    ).
    catch(this.errorHandler)


  }

  getCourseById(data):Promise<any>{

    return this.http.get('http://localhost:3333/SelfPaced_BackEnd/SelfPaced/getCourseById/'+data).
    toPromise().
    then(res=> res.json()) 
    .catch(this.errorHandler)
  }





  errorHandler(error){
    return Promise.reject(error.json() || error)
  }


  dispPass(){
    if(this.password=="password"){
     this.password="text";
     this.open="close"
   }
     else{
     this.password="password";
     this.open="open";
     }
   }


   getallCourses()
   {
     return this.http.get('http://localhost:3333/SelfPaced_BackEnd/SelfPaced/getallCourses').
     toPromise().
     then(res=>res.json() as Course[]
     ).
     catch(this.errorHandler); 
   }



   getQuestionsByCourseId(data):Promise<any>{

    return this.http.get('http://localhost:3333/SelfPaced_BackEnd/SelfPaced/getQuestionsByCourseId/'+data).
    toPromise().
    then(res=> res.json() as Question_Bank[]) 
    .catch(this.errorHandler)
  }



  completeCourse(data)
  {
    return this.http.post('http://localhost:3333/SelfPaced_BackEnd/SelfPaced/completeCourse',data).
    toPromise().
    then(res=> res.json() as EmployeeCourse) 
    .catch(this.errorHandler)
  }

  getCompletedCourses(data)
  {
    return this.http.get('http://localhost:3333/SelfPaced_BackEnd/SelfPaced/getCompletedCourses/'+data).
    toPromise().
    then(res=>res.json() as Course[]).
    catch(this.errorHandler)

  }

  generateCertificate(empid,courseid)
  {

    return this.http.get('http://localhost:3333/SelfPaced_BackEnd/SelfPaced/generateCertificate/'+empid+"/"+courseid).
    toPromise().
    then(res=>res.json() as Course).
    catch(this.errorHandler)

  }



 
 
}



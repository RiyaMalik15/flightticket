import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AccessApiService } from '../access-api.service';
import { customValidator } from '../validator';
import { Employee } from '../model/Employee';
import { Router } from '@angular/router';


@Component({
  selector: 'app-forget-password',
  templateUrl: './forget-password.component.html',
  styleUrls: ['./forget-password.component.css']
})
export class ForgetPasswordComponent implements OnInit {

  errorMessage: string;
  successMessage : string;
  empid:number;
  status=false;
  resetpassword : FormGroup;
  employee:Employee;
  changepassword:FormGroup;
  constructor(private fb : FormBuilder, private service : AccessApiService,private route:Router) { }

  ngOnInit() {
    this.resetpassword = this.fb.group({
      name : ['',[Validators.required]],
      dob : ['',[Validators.required]],
      email :['',[Validators.required, Validators.email]],
      phone_Number : ['',[Validators.required, Validators.pattern("[0-9]{10}")]]
      // area_Of_Intrest : ['',[Validators.required]]   <-- edit in phase 2
    })


    this.changepassword=this.fb.group({
      password : ['',[Validators.required,customValidator.checkpassword]],
      re_Pass : ['',[Validators.required,customValidator.checkpassword]]
    })
  }

  check(){
    if(this.changepassword.controls.password.value==this.changepassword.controls.re_Pass.value){
      this.status=true;
    } 
    else{
      this.status=false;
    }
  }


  check_details()
  {

    this.service.check_details(this.resetpassword.value)
    .then(res=>this.empid=res.empid)
    .catch(err=>this.errorMessage=err.message)
    
  }

  change_password(){

    this.employee=new Employee()
    this.employee.empid=this.empid;
    this.employee.password=this.changepassword.controls.password.value;
    
   
    
    this.service.change_password(this.employee)
    .then(res=>{
      this.successMessage=res; 
      this.route.navigate(['/login']);
      
    })
    .catch(err=>this.errorMessage=err)
    

  }


}

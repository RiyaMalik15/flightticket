import { Component, OnInit } from '@angular/core';
import { Feedback } from '../model/Feedback';
import { AccessApiService } from '../access-api.service';
import { Employee } from '../model/Employee';

@Component({
  selector: 'app-show-employee',
  templateUrl: './show-employee.component.html',
  styleUrls: ['./show-employee.component.css']
})
export class ShowEmployeeComponent implements OnInit {

  employee:Employee[];
  message;
  base={}
  course = Object.create(this.base);

  constructor(private ser:AccessApiService) { }

  ngOnInit() {
    
    this.ser.getallEmployees()
    .then(res=>{
      this.employee=res
      this.getCompletedCourses(this.employee)
    })
    .catch(err=>this.message=err[0].message);
    
  }

  getCompletedCourses(emp:Employee[])
  {
    for(let e of emp)
    {

      this.ser.getCompletedCourses(e.empid)
      .then(res=>{
        this.course[e.empid]=res
        console.log(this.course[e.empid])  
      })
      .catch(err=>err);   
    }
 
  }
  
}

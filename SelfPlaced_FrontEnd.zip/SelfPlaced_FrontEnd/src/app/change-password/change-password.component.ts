import { Component, OnInit } from '@angular/core';
import { Validators, FormGroup, FormBuilder } from '@angular/forms';
import { customValidator } from '../validator';
import { Employee } from '../model/Employee';
import { AccessApiService } from '../access-api.service';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {

  op="open";
  pass="password";
  status=false;
  changepassword:FormGroup;
  errorMessage:string;
  successMessage:string
  constructor(private fb : FormBuilder,private service:AccessApiService) { }
employee:Employee;
  ngOnInit() {
    this.changepassword=this.fb.group({
      old_Password:['',[Validators.required,customValidator.checkpassword]],
      password : ['aaaaa',[Validators.required,customValidator.checkpassword]],
      re_Pass : ['aaaa',[Validators.required,customValidator.checkpassword]]
    })
    this.employee=JSON.parse(sessionStorage.getItem("employee"));

  }


  change_password()
  {
    var pass:string=this.employee.password
    var opass:string=this.changepassword.controls.old_Password.value
    
    if(pass!=opass)
    {
      this.errorMessage="Old Password Is Incorrect"
    }
    else
    {
      this.errorMessage=null;
      this.employee.password=this.changepassword.controls.password.value;
      this.service.change_password(this.employee)
      .then(res=>this.successMessage=res)
      .catch();

      sessionStorage.setItem("employee",JSON.stringify(this.employee))
      
    }

  }
  check(){
    if(this.changepassword.controls.password.value==this.changepassword.controls.re_Pass.value){
      this.status=true;
    } 
    else{
      this.status=false;
    }
  }

  dispPassword(){
    if(this.pass=="password"){
     this.pass="text";
     this.op="close"
   }
     else{
     this.pass="password";
     this.op="open";
     }
   }
 


}

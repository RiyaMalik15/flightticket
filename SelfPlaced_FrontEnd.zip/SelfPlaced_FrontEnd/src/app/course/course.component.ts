import { Component, OnInit } from '@angular/core';
import { ParamMap, Router, ActivatedRoute } from '@angular/router';
import { AccessApiService } from '../access-api.service';
import { Course } from '../model/Course';

@Component({
  selector: 'app-course',
  templateUrl: './course.component.html',
  styleUrls: ['./course.component.css']
})
export class CourseComponent implements OnInit {

  courseid;


  constructor(private router:Router,private route:ActivatedRoute,private ser:AccessApiService) { }

  ngOnInit() {
    this.route.paramMap
              .subscribe( (params: ParamMap) =>{
               this.courseid= parseInt(params.get('courseid'))
              });

   

  }

  test()
  {

    this.router.navigate(['../../test',this.courseid],{relativeTo:this.route});
  }


}

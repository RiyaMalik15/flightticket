export class Course
{
    courseid:number;
	no_Of_Enroll:number;
	duration:number;
	course_Name:string;
	description:string;
	message:string;
}
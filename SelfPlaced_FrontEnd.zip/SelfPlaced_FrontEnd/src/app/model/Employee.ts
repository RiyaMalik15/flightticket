import { Course } from "./Course";

export class Employee
{
    empid:number;
    name:string;
    dob:Date;
    password:string;
    email:string;
    ranking:number;
    badges:number;
    phone_Number:number;
    courses: Course[];
    message:string;

}
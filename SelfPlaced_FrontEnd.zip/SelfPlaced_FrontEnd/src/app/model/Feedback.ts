export class Feedback{
    reviews:string;
	empid:number;
	courseid:number;
	feedbackid:number;
	message:string;
}
export class Question_Bank
{
     question_Number:number;
	 question:string;
	 option_A:string;
	 option_B:string;
	 option_C:string;
	 option_D:string;
	 answer:string;
	 courseid:number;
}
export class EmployeeCourse
{
    courseid:number;
	empid:number;
	status:string;
	trails:number;
	max_Score:number;
}
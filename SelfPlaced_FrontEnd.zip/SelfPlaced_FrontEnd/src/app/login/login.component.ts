import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms/src/model';
import { FormBuilder } from '@angular/forms';
import { Validators } from '@angular/forms';
import { customValidator } from '../validator';
import { AccessApiService } from '../access-api.service';
import { Employee } from '../model/Employee';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  successMessage:string;
  errorMessage:string;
  loginForm : FormGroup;
  employee:Employee;
  constructor(private fb : FormBuilder, private service : AccessApiService,private router:Router) { }

  ngOnInit() {
    this.loginForm = this.fb.group({
      email: ['',[Validators.required,Validators.email]],
      password: ['',[Validators.required,customValidator.checkpassword]]
    })
  }


  loginEmployee(){
  
    // 
    this.successMessage = null;
    this.errorMessage = null;
    this.service.loginEmployee(this.loginForm.value)
    .then(res => {
      this.employee=res;
      sessionStorage.setItem("employee",JSON.stringify(this.employee))
      this.router.navigate(['login',this.employee.empid]);
      this.service.isUserLoggedin=true;
    })
    .catch((err) => this.errorMessage = err.message)
  }




}


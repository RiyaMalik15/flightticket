import { Component, OnInit } from '@angular/core';
import { ParamMap, Router, ActivatedRoute } from '@angular/router';
import { AccessApiService } from '../access-api.service';
import { Course } from '../model/Course';
import { Question_Bank } from '../model/Question_Bank';
import { FormBuilder } from '@angular/forms';
import { FormGroup, FormArray } from '@angular/forms';
import { Employee } from '../model/Employee';
import { element } from 'protractor';
import { EmployeeCourse } from '../model/EmployeeCourse';
import { Location } from '@angular/common';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {

  rank="";
  empcou:EmployeeCourse;
  courseid;
  courseName="gfdfg";
  course:Course;
  answer:FormGroup
  questions:Question_Bank[];
  score:any;
  employee:Employee
  empans:string[]=[]
  correctans:string[]=[]
  x;
status=true;
  constructor(private router:Router,private route:ActivatedRoute,private ser:AccessApiService,private fb:FormBuilder,private loc:Location) { }

  ngOnInit() {

    
    this.start()
    this.route.paramMap
              .subscribe( (params: ParamMap) =>{
               this.courseid= parseInt(params.get('courseid'))
              });
   
              this.ser.getCourseById(this.courseid)
              .then(res=> {
                this.course=res
                this.courseName=this.course.course_Name;
              })
              .catch(err=>err)
                        

    this.ser.getQuestionsByCourseId(this.courseid)
    .then(res=>{
       this.questions=res
       this.getallans();
       console.log(this.correctans)
      })
    .catch(err=>err)

 
   

    this.answer=this.fb.group({
      option:this.fb.array(['','','','','','','','','',''])
    })    


    this.employee=JSON.parse(sessionStorage.getItem("employee"))
}


submitans(){
  clearInterval(this.x);

this.status=false;

  this.empans=this.answer.controls.option.value;
console.log(this.empans)


console.log(this.correctans)

  this.score=0;
   for(let i in this.empans)
  {
    
    if(this.empans[i]==this.correctans[i])
      this.score=this.score+1;
    else if(this.empans[i]!=this.correctans[i] && this.empans[i]!='e')
      this.score-=0.25;
    console.log(this.score)
    }

  this.score=this.score*10
  this.completeCourse();
}


getallans()
{

  for( let i of this.questions){
    this.correctans.push(i.answer);
}



}

back()
{
  this.status=!this.status;
}

start()
{
  var d = new Date();
  d.setMinutes(d.getMinutes()+10);

  var count=d.getTime();
   this.x = setInterval(function() {
    var now = new Date().getTime();
    var distance = count - now;
    var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    document.getElementById("demo").innerHTML = minutes + "m " + seconds + "s "
    if(minutes==0)
    {
        document.getElementById("demo").classList.remove('text-success');
        document.getElementById("demo").classList.add('text-danger');
    }
    if (distance < 0) {
      clearInterval(this.x);
      document.getElementById("submit").click();
    }
  }, 1000);

}


scrollToElement($element): void {  
  document.getElementById($element).scrollIntoView()
}


clearans(i)
{

  this.answer.controls.option.value[i]='';
}



completeCourse()
{

  this.empcou=new EmployeeCourse()
  this.empcou.courseid=this.courseid;
  this.empcou.empid=this.employee.empid;
  this.empcou.max_Score=this.score;
  this.ser.completeCourse(this.empcou)
  .then(res=>{
    this.empcou=res
    this.getRank();
  })
  .catch(err=>err)

}

retry()
{ 
  this.router.navigate(['../../course/',this.courseid],{relativeTo:this.route})
}

getRank(){

  this.ser.getEmployeeById(this.employee.empid)
  .then(res=>{
    this.employee=res
    this.rank=res.ranking;
    sessionStorage.setItem("employee",JSON.stringify(this.employee))
  })
  .catch(err=>err)
}
}

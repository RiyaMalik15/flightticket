import { Component, OnInit } from '@angular/core';
import { AccessApiService } from '../access-api.service';


import { Router, ParamMap } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { Employee } from '../model/Employee';
import { FormBuilder } from '@angular/forms';
import { FormGroup } from '@angular/forms';
import { BadgePipe } from '../pipe/badge.pipe';

@Component({
  selector: 'app-login-home',
  templateUrl: './login-home.component.html',
  styleUrls: ['./login-home.component.css']
})
export class LoginHomeComponent implements OnInit {

searchform:FormGroup;
  employee:Employee;
    empid:number;
  constructor(private ser:AccessApiService,private router:Router,private route:ActivatedRoute,private fb :FormBuilder) { 
    this.ser.isUserLoggedin=true;
  }

  ngOnInit() {
    this.employee = new Employee();
    this.route.paramMap
              .subscribe( (params: ParamMap) =>{
               this.empid= parseInt(params.get('id'))
              });
              

    this.ser.getEmployeeById(this.empid)
    .then(res=>{
      this.employee=res;   
      sessionStorage.setItem("employee",JSON.stringify(this.employee)) 
    })
    this.ser.getEmployeeById(this.empid)
    .then(res=>{
      this.employee=res;   
      sessionStorage.setItem("employee",JSON.stringify(this.employee)) 
    })
    .catch(err=>this.employee.message=err.message)  
   
  


    this.searchform=this.fb.group({
      search:['']
    })
  }

  same(){
    this.router.navigate(['../login',this.empid])
  }

  logout()
  {
    if(confirm("Are You Sure You Want To Exit "))
    {
      sessionStorage.setItem("employee",null);
      this.ser.isUserLoggedin=false;
      this.router.navigate(['../'])

    }
  }


  courseSearch(data:string){

    var search:string=this.searchform.controls.search.value;
    search=search.toUpperCase();
    if(data.includes(search))
      return true;
    else
      return false;
  }


}

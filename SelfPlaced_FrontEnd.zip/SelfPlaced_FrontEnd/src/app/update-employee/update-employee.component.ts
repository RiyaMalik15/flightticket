import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AccessApiService } from '../access-api.service';
import { customValidator } from '../validator';
import { Employee } from '../model/Employee';
import { DatePipe, Location } from '@angular/common';

@Component({
  selector: 'app-update-employee',
  templateUrl: './update-employee.component.html',
  styleUrls: ['./update-employee.component.css']
})
export class UpdateEmployeeComponent implements OnInit {

  errorMessage: string;
  successMessage : string;
  employee:Employee;
  signUpForm : FormGroup;
  constructor(private fb : FormBuilder, private service : AccessApiService,private loc:Location) { }

  ngOnInit() {
    this.signUpForm = this.fb.group({
      name : ['',[Validators.required]],
      dob : ['',[Validators.required]],
      phone_Number : ['',[Validators.required, Validators.pattern("[0-9]{10}")]]
    })

    this.employee=JSON.parse(sessionStorage.getItem("employee"));
    var datePipe=new DatePipe("en-US");
    this.signUpForm.controls.name.setValue(this.employee.name);
  
    this.signUpForm.controls.dob.setValue(datePipe.transform(this.employee.dob,'MM/dd/yyyy'));
    this.signUpForm.controls.phone_Number.setValue(this.employee.phone_Number)
  }



  updateEmployee()
  {
    this.employee.name=this.signUpForm.controls.name.value;
    this.employee.dob=this.signUpForm.controls.dob.value;
    this.employee.phone_Number=this.signUpForm.controls.phone_Number.value;
    
    this.service.updateEmployee(this.employee)
    .then(res=>{
      this.employee=res;
      sessionStorage.setItem("employee",JSON.stringify(this.employee));
      this.loc.back();
    })
    .catch(err=>this.errorMessage=err.message);
  }

}

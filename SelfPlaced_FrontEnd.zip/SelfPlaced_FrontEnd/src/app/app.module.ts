import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule }    from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { HomeComponent } from './home/home.component';
import {Routes, RouterModule} from '@angular/router';
import { AccessApiService } from './access-api.service';
import { HttpModule } from '@angular/http';
import { AppRoutingModule } from './app-routing.module';
import { ForgetPasswordComponent } from './forget-password/forget-password.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoginHomeComponent } from './login-home/login-home.component';
import { AuthGuard } from './auth/auth.guard';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { UpdateEmployeeComponent } from './update-employee/update-employee.component';
import { AdminComponent } from './admin/admin.component';
import { ShowEmployeeComponent } from './show-employee/show-employee.component';
import { ShowFeedbackComponent } from './show-feedback/show-feedback.component';
import { AdminGuard } from './auth/admin.guard';
import { ShowcourseComponent } from './showcourse/showcourse.component';

import { EmployeehomeComponent } from './employeehome/employeehome.component';
import { CourseComponent } from './course/course.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { TestComponent } from './test/test.component';
import { TestGuard } from './auth/test.guard';
import { BadgePipe } from './pipe/badge.pipe';
import { CertificateComponent } from './certificate/certificate.component';




@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignupComponent,
    HomeComponent,  
    ForgetPasswordComponent,
    LoginHomeComponent,
    ChangePasswordComponent,
    AboutUsComponent,
    UpdateEmployeeComponent,
    AdminComponent,
    ShowEmployeeComponent,
    ShowFeedbackComponent,
    ShowcourseComponent,
    EmployeehomeComponent,
    CourseComponent,
    FeedbackComponent,
    TestComponent,
    BadgePipe,
    CertificateComponent
    
    
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule,
    AppRoutingModule,
    HttpModule,
    BrowserAnimationsModule
  ],
  providers: [AccessApiService,AuthGuard,AdminGuard,TestGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }

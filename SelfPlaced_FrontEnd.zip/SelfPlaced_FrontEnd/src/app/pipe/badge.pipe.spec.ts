import { BadgePipe } from './badge.pipe';

describe('BadgePipe', () => {
  it('create an instance', () => {
    const pipe = new BadgePipe();
    expect(pipe).toBeTruthy();
  });
});

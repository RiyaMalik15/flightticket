import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'badge'
})
export class BadgePipe implements PipeTransform {

  transform(value: any, args?: any): any {
    
    var arr=[];
    for(let i=0;i<value;i++)
    {
      arr.push(i)
    }

    return arr;
  }

}

import { Component, OnInit } from '@angular/core';
import { Employee } from '../model/Employee';
import { Course } from '../model/Course';
import { FormGroup } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { AccessApiService } from '../access-api.service';
import { Validators } from '@angular/forms';
import { Feedback } from '../model/Feedback';
import { Location } from '@angular/common';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {
  employee:Employee;
  course:Course[];
  feedback:FormGroup;
  feed:Feedback;

  constructor(private ser:AccessApiService,private router:Router,private route:ActivatedRoute,private fb :FormBuilder,private loc:Location) { }
  

 
  ngOnInit() {

    this.employee=JSON.parse(sessionStorage.getItem("employee"));
    this.course=this.employee.courses;
    
    this.feedback=this.fb.group({
      courseid:['',[Validators.required]],
      reviews:['',[Validators.required]],
      rate:['2',[Validators.required]]
    })
  }


  addFeedback(){  

    this.feed=new Feedback()
    this.feed.empid=this.employee.empid;
    this.feed.courseid=this.feedback.get('courseid').value;
    this.feed.reviews=this.feedback.controls.reviews.value;
 
    this.ser.addFeedback(this.feed)
            .then(res=>{
              this.feed=res;
              this.router.navigate(['../'],{relativeTo:this.route});
            })
            .catch(err=>err.message)


  }

  back()
  {
    this.router.navigate(['../'],{relativeTo:this.route});
  }



}

import { AbstractControl } from "@angular/forms/src/model";

export class customValidator
{
    static checkpassword(control:AbstractControl)
    {
        let pass:string=control.value as string
        var regex1="[A-Za-z]";
        var regex2="[A-Za-z0-9]";
        if(pass.match(regex1) || pass.match(regex2))
        {
            return null;
        }   
        return { 'checkpassword':true} 
    }
}


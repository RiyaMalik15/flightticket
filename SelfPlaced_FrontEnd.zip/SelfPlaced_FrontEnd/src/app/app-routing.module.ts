import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { HomeComponent } from './home/home.component';
import { ForgetPasswordComponent } from './forget-password/forget-password.component';
import { LoginHomeComponent } from './login-home/login-home.component';
import { AuthGuard } from './auth/auth.guard';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { UpdateEmployeeComponent } from './update-employee/update-employee.component';
import { AdminComponent } from './admin/admin.component';
import { ShowEmployeeComponent } from './show-employee/show-employee.component';
import { ShowFeedbackComponent } from './show-feedback/show-feedback.component';
import { AdminGuard } from './auth/admin.guard';
import { ShowcourseComponent } from './showcourse/showcourse.component';

import { EmployeehomeComponent } from './employeehome/employeehome.component';
import { CourseComponent } from './course/course.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { TestComponent } from './test/test.component';
import { TestGuard } from './auth/test.guard';

import { CertificateComponent } from './certificate/certificate.component';

const routes : Routes = [
    {
      path: 'signup',
      component: SignupComponent
    },
    {
      path: 'login',
      component: LoginComponent
    },
    {
      path: 'home',
      component: HomeComponent
    },
    {
      path:'',
      redirectTo:'home',
      pathMatch:'full'
    },
    {
      path: 'forgetpassword', 
      component: ForgetPasswordComponent
    },
    {
      path: 'about', 
      component: AboutUsComponent
    },
    {
      path: 'login/:id',
      canActivate: [AuthGuard],
      // canActivateChild:[AuthGuard],
      canDeactivate:[AuthGuard],
      component: LoginHomeComponent,
      children:[
        {
          path:'emphome',
          component: EmployeehomeComponent
        },
        {
          path:'',
          redirectTo:'emphome',
          pathMatch:'full'
        },
        {
          path: 'password', 
          component: ChangePasswordComponent
        },
        {
          path: 'update', 
          component: UpdateEmployeeComponent
        },
        {
          path: 'feedback', 
          component: FeedbackComponent
        },
        {
          path: 'course/:courseid', 
          component:CourseComponent,
         
        },
        {
          path:'test/:courseid',
          component:TestComponent, 
          canDeactivate:[TestGuard]
        },
        {
          path:'certificate',
          component:CertificateComponent
        }
      ]},
    {
      path:'admin',
      component:AdminComponent,
      //  canActivate:[AdminGuard],
      children:[
        {
          path: 'show_Employee',
          component: ShowEmployeeComponent
        },
        {
          path: 'show_Feedback',
          component: ShowFeedbackComponent
        },
        {
          path: 'show_Course',
          component: ShowcourseComponent
        },
        
      ]}
    
  ]
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

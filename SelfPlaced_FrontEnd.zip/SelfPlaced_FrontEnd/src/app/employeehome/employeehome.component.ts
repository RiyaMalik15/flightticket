import { Component, OnInit } from '@angular/core';
import { LoginHomeComponent } from '../login-home/login-home.component';
import { AccessApiService } from '../access-api.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Course } from '../model/Course';
import { Employee } from '../model/Employee';

@Component({
  selector: 'app-employeehome',
  templateUrl: './employeehome.component.html',
  styleUrls: ['./employeehome.component.css']
})
export class EmployeehomeComponent implements OnInit {
  empid;
  courseid;
  message;
  course:Course
  employee:Employee
  constructor(private lh:LoginHomeComponent,private router:Router,private route:ActivatedRoute,private ser:AccessApiService){ }
  loginhome:LoginHomeComponent;
  ngOnInit() {
  this.empid=JSON.parse(sessionStorage.getItem("employee")).empid;
  this.employee=JSON.parse(sessionStorage.getItem("employee"))
  
  }
  courseAllocation(courseid)
  {
  
    this.ser.courseAllocation(courseid,this.empid)
            .then(res=>{
              this.course=res
              this.employee.courses.push(this.course)
              sessionStorage.setItem("employee",JSON.stringify(this.employee))
            
            })
            .catch(err=>this.message=err.message)

            this.router.navigate(['../course',courseid],{relativeTo:this.route});
    
}

}

import { Component, OnInit } from '@angular/core';
import { Feedback } from '../model/Feedback';
import { AccessApiService } from '../access-api.service';
import { Employee } from '../model/Employee';

@Component({
  selector: 'app-show-feedback',
  templateUrl: './show-feedback.component.html',
  styleUrls: ['./show-feedback.component.css']
})
export class ShowFeedbackComponent implements OnInit {

  feedback:Feedback[];
  message;
   base = {};
  
   
  employee = Object.create(this.base);
  course = Object.create(this.base);
 

  
  constructor(private ser:AccessApiService) { 
  
    
  
    
  }

  ngOnInit() {

    this.ser.getallFeedbacks()
    .then(res=>{
      this.feedback=res
      for(let feed of this.feedback){
        this.setempname(feed.empid);
        this.setcoursename(feed.courseid)
      }
    })
    .catch(err=>this.message=err[0].message);
    
  }

  setempname(data)
  {
    this.ser.getEmployeeById(data)
    .then(res=>this.employee[data]=res.name)
    .catch(err=>this.message=err[0].message);

  }

  setcoursename(data)
  {
    this.ser.getCourseById(data)
    .then(res=>this.course[data]=res.course_Name)
    .catch(err=>this.message=err[0].message);

  }


 
}

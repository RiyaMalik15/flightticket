import { Component, OnInit } from '@angular/core';
import { AccessApiService } from '../access-api.service';
import { ActivatedRoute,Router } from '@angular/router';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  constructor(private ser:AccessApiService,private router:Router) {
    this.ser.isUserLoggedin=true;
   }

  ngOnInit() { }


  logout()
  {
    if(confirm("Are You Sure You Want To Exit "))
    {
    
      this.ser.isUserLoggedin=false;
      this.router.navigate(['../'])

    }
  }


}

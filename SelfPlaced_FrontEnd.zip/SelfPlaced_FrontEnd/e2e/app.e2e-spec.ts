import { Li9baaaPage } from './app.po';

describe('li9baaa App', () => {
  let page: Li9baaaPage;

  beforeEach(() => {
    page = new Li9baaaPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!');
  });
});

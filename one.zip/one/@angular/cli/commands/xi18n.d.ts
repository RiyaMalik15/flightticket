export interface Xi18nOptions {
    outputPath?: string;
    verbose?: boolean;
    i18nFormat?: string;
    locale?: string;
    outFile?: string;
}
declare const Xi18nCommand: any;
export default Xi18nCommand;

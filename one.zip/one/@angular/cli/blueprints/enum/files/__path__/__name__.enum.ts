export enum <%= classifiedModuleName %> {
}

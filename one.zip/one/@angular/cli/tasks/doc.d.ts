export declare const DocTask: any;

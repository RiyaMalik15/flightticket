export declare function it(description: string, fn: () => PromiseLike<any> | void): any;

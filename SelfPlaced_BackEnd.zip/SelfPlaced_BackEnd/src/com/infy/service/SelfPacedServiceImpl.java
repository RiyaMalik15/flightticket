package com.infy.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.infy.AES.Certificate;
import com.infy.dao.SelfPacedDAO;
import com.infy.model.Course;
import com.infy.model.Employee;
import com.infy.model.EmployeeCourse;
import com.infy.model.Feedback;
import com.infy.model.Question_Bank;

@Service(value = "Service") 
@Transactional(readOnly = true)
public class SelfPacedServiceImpl implements SelfPacedService {

	@Autowired
	private SelfPacedDAO DAO;

	@Transactional(readOnly = false,propagation=Propagation.REQUIRES_NEW)
	@Override
	public Integer addEmployee(Employee employee) throws Exception {
		
		System.out.println("kjhgjhgjhgh");
		Integer empid=DAO.addEmployee(employee);
		System.out.println("iughjgjhgjh");
		if(empid==null)
			throw new Exception("Service.EMPLOYEE_ALREADY_EXISTS");
		else
			return empid;
		
		
	}

	@Transactional(readOnly = false,propagation=Propagation.REQUIRES_NEW)
	@Override
	public Integer addFeedback(Feedback feedback) throws Exception {
		
		Integer feed=DAO.addFeedback(feedback);
		if(feed==null)
			throw new Exception();
		else
			return feed;
		
	}

	@Transactional(readOnly = false,propagation=Propagation.REQUIRES_NEW)
	@Override
	public Course courseAllocation(Integer courseid,Integer empid)
			throws Exception {
		
		Course c=DAO.courseAllocation(courseid,empid);
		
			return c;
		
		
	}

	@Transactional(readOnly = false,propagation=Propagation.REQUIRES_NEW)
	@Override
	public Integer calculateBadge(Integer empid) throws Exception {
		
		return DAO.calculateBadge(empid);
	}

	@Transactional(readOnly = false,propagation=Propagation.REQUIRES_NEW)
	@Override
	public Employee loginEmployee(Employee employee) throws Exception {
		
		Employee e=DAO.loginEmployee(employee);
		if(e==null)
			throw new Exception("Service.LOGIN_FAILURE_PASS_MM");
		else
			return e;
		
	}


	@Transactional(readOnly = false,propagation=Propagation.REQUIRES_NEW)
	@Override
	public Employee getEmployeeById(Integer empid) throws Exception {
		
		return DAO.getEmployeeById(empid);
	}


	@Transactional(readOnly = false,propagation=Propagation.REQUIRES_NEW)
	@Override
	public Employee check_details(Employee employee) throws Exception {
		
		return DAO.check_details(employee);
	}
	

	@Transactional(readOnly = false,propagation=Propagation.REQUIRES_NEW)
	@Override
	public String change_password(Integer empid, String password)
			throws Exception {
		// TODO Auto-generated method stub
		return DAO.change_password(empid, password);
	}
	@Transactional(readOnly = false,propagation=Propagation.REQUIRES_NEW)
	@Override
	public Employee updateEmployee(Employee employee) throws Exception {
		
		return DAO.updateEmployee(employee);
	}

	@Override
	public List<Employee> getallEmployees() throws Exception {
		
		return DAO.getallEmployees();
	}

	@Override
	public List<Feedback> getallFeedbacks() throws Exception {
		// TODO Auto-generated method stub
		return DAO.getallFeedbacks();
	}

	@Override
	public Course getCourseById(Integer courseid) throws Exception {
		// TODO Auto-generated method stub
		return DAO.getCourseById(courseid);
	}

	@Override
	public List<Course> getallCourses() throws Exception {
		// TODO Auto-generated method stub
		return DAO.getallCourses();
	}

	@Override
	public List<Question_Bank> getQuestionsByCourseId(Integer courseid)
			throws Exception 
	{
		
		return DAO.getQuestionsByCourseId(courseid);
	}

	@Transactional(readOnly = false,propagation=Propagation.REQUIRES_NEW)
	@Override
	public EmployeeCourse completeCourse(EmployeeCourse employeeCourse)  throws Exception{
		// TODO Auto-generated method stub
		return DAO.completeCourse(employeeCourse);
	}

	@Override
	public List<Course> getCompletedCourses(Integer empid) throws Exception {
		
		return DAO.getCompletedCourses(empid);
	}

	@Override
	public String generateCertificate(Integer courseid, Integer empid)
			throws Exception {
		
		Employee emp=getEmployeeById(empid);
		Course cou=getCourseById(courseid);
		String url=Certificate.generateCertificate(emp.getName(), cou.getCourse_Name());
		return url;
		
	}

	
	


}

package com.infy.service;

import com.infy.model.Course;
import com.infy.model.Employee;
import com.infy.model.EmployeeCourse;
import com.infy.model.Feedback;
import com.infy.model.Question_Bank;

import java.util.*;
public interface SelfPacedService {
	
	public Integer addEmployee(Employee employee) throws Exception;
	
	public Integer addFeedback(Feedback feedback) throws Exception;
	
	public Course courseAllocation(Integer courseid,Integer empid) throws Exception;
	
	public Integer calculateBadge(Integer empid) throws Exception;
	
	public Employee loginEmployee(Employee employee) throws Exception;
	
	public Employee getEmployeeById(Integer empid) throws Exception;
	
	public Employee check_details(Employee employee) throws Exception;
	
	public String change_password(Integer empid,String password) throws Exception;
	
	public Employee updateEmployee(Employee employee) throws Exception;
	
	public List<Employee> getallEmployees() throws Exception;
	
	public List<Feedback> getallFeedbacks() throws Exception;
	
	public Course getCourseById(Integer courseid) throws Exception;
	
	
	public List<Course> getallCourses() throws Exception;
	
	public List<Question_Bank> getQuestionsByCourseId(Integer courseid) throws Exception;
	
	public EmployeeCourse completeCourse(EmployeeCourse employeeCourse)  throws Exception;
	
	public List<Course> getCompletedCourses(Integer empid) throws Exception;
	
	
	public String generateCertificate(Integer courseid,Integer empid) throws Exception;
	
}

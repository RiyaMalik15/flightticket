package com.infy.utility;

import java.io.File;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.LoggerContext;
import org.apache.logging.log4j.status.StatusLogger;

public class LogConfig {

	static {	
		StatusLogger.getLogger().setLevel(Level.OFF);
		String path = LogConfig.class.getResource("/com/infy/resources/log4j2.xml").getPath();
		((LoggerContext) LogManager.getContext(false)).setConfigLocation(new File(path).toURI());
	}
	
	/* Use this method to get the logger object */
	public static Logger getLogger(Class<?> clazz) {
		return LogManager.getLogger(clazz);
	}
}
package com.infy.AES;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
 

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

public class Encrypt_Decrypt {

	 static String key = "DB99A2A8EB6904F492E9DF0595ED683C";

	 
    private static String byteArrayToHexString(byte[] b) {
        StringBuffer sb = new StringBuffer(b.length * 2);
        for (int i = 0; i < b.length; i++) {
            int v = b[i] & 0xff;
            if (v < 16) {
                sb.append('0');
            }
            sb.append(Integer.toHexString(v));
        }
        return sb.toString().toUpperCase();
    }

    private static byte[] hexStringToByteArray(String s) {
        byte[] b = new byte[s.length() / 2];
        for (int i = 0; i < b.length; i++) {
            int index = i * 2;
            int v = Integer.parseInt(s.substring(index, index + 2), 16);
            b[i] = (byte) v;
        }
        return b;
    }
    
    
    
    public static void main(String args[]) throws Exception
 
    {
    
        String password="Srm123#";
        String enc=encrpytpass(password);
        encrpytpass(password);
       decrpytpass("05079DD8972F6FD171402147DDBE4B73");		

    }
    
    
    
    
    public static String encrpytpass(String str)  
    {
    	String encryptedpwd=null;
    	try{
        byte[] bytekey = hexStringToByteArray(key);
        SecretKeySpec sks = new SecretKeySpec(bytekey, "AES");
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.ENCRYPT_MODE, sks, cipher.getParameters());
      
        
        

        byte[] encrypted = cipher.doFinal(str.getBytes());
        encryptedpwd = byteArrayToHexString(encrypted);
       
        return encryptedpwd;
    	}
        catch(Exception e)
        {
        	
        }
        return encryptedpwd;
    }
    
    
    public static String decrpytpass(String str) 
    {
    	String OriginalPassword =null;
        try{
        byte[] bytekey1 = hexStringToByteArray(key);
        SecretKeySpec sks1 = new SecretKeySpec(bytekey1,"AES");
        Cipher cipher1 = Cipher.getInstance("AES");
        cipher1.init(cipher1.DECRYPT_MODE, sks1);
        
        


        byte[] decrypted = cipher1.doFinal(hexStringToByteArray(str));
        OriginalPassword = new String(decrypted);
        
        return OriginalPassword;
        
        }
        catch(Exception e)
        {
        	e.printStackTrace();
        }
        return OriginalPassword;
    }
}
 
   
 



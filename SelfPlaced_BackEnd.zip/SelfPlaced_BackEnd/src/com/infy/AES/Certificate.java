
package com.infy.AES;


import java.net.MalformedURLException;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;


public class Certificate{
	public static String generateCertificate(String empname,String coursename) throws Exception {
		

 
		WebDriver driver;
		String url_olx = "https://www.terryberry.com/build-a-certificate/";
	//Set the key/value property according to the browser you are using.
	System.setProperty("webdriver.chrome.driver","C:\\chromedriver.exe");
	driver = new ChromeDriver();
	driver.manage().window().setPosition(new Point(-2000, 0));
	driver.get(url_olx);
	Thread.sleep(2000);
	driver.findElement(By.id("template")).click();
	driver.findElement(By.id("recipient-name")).sendKeys(empname.toUpperCase());
	Thread.sleep(1000);
	String desc="This is to certify that he/she has completed "+coursename+" Course from Self -Paced Learning We found him/her sincere, hardworking ,dedicated and result oriented He/her worked well during his/her tenure. We take this opportunity to thank him/her and wish him/her All The Best for his/her Future";			
    driver.findElement(By.id("description")).sendKeys(desc);
    Thread.sleep(2000);
    driver.findElement(By.id("manager-name")).sendKeys("SelfPaced Learning");
    Thread.sleep(2000);
    driver.findElement(By.id("manager-title")).sendKeys("Infosys Mysore");
    Thread.sleep(2000);
    
    LocalDate date=LocalDate.now();
    String dt=date.format(DateTimeFormatter.ofPattern("dd MMMM yyyy"));
    driver.findElement(By.id("cert-date")).sendKeys(dt);
    
    Thread.sleep(3000);
    driver.findElement(By.id("create-certificate")).click();
    Thread.sleep(5000);
    String url = driver.getCurrentUrl();
		//Close the browser
    System.out.println(url);
		driver.quit();
		return url;
	}
	
	
	
	
	
	
	
	
	
	
}

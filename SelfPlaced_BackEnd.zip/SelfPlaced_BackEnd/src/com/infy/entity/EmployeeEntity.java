package com.infy.entity;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.annotations.GenericGenerator;








import com.infy.AES.Encrypt_Decrypt;
import com.infy.model.Course;
import com.infy.model.Employee;

@Entity
@Table(name = "EMPLOYEE")
@GenericGenerator(name = "pkgen", strategy = "increment")	
public class EmployeeEntity {
	
	@Id
	@GeneratedValue(generator = "pkgen")
	private Integer empid;
	private String name;
	private LocalDate dob;
	private String password;
	private String email;
	private Integer ranking;
	private Integer badges;
	private Long phone_Number;
	
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "EmpCourse", 
	joinColumns = @JoinColumn(name = "empid", referencedColumnName = "empid"), 
	inverseJoinColumns = @JoinColumn(name = "courseid", referencedColumnName = "courseid"))
	private List<CourseEntity> courses;
	
	public List<CourseEntity> getCourses() {
		return courses;
	}
	public void setCourses(List<CourseEntity> courses) {
		this.courses = courses;
	}
	public Integer getEmpid() {
		return empid;
	}
	public void setEmpid(Integer empid) {
		this.empid = empid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public LocalDate getDob() {
		return dob;
	}
	public void setDob(LocalDate dob) {
		this.dob = dob;
	}
	public String getPassword() {
		return Encrypt_Decrypt.decrpytpass(password);
	}
	public void setPassword(String password) {
		this.password = Encrypt_Decrypt.encrpytpass(password);
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Integer getRanking() {
		return ranking;
	}
	public void setRanking(Integer ranking) {
		this.ranking = ranking;
	}
	public Integer getBadges() {
		return badges;
	}
	public void setBadges(Integer badges) {
		this.badges = badges;
	}
	public Long getPhone_Number() {
		return phone_Number;
	}
	public void setPhone_Number(Long phone_Number) {
		this.phone_Number = phone_Number;
	}
	
	public EmployeeEntity() {
		// TODO Auto-generated constructor stub
	}
	
	public EmployeeEntity(Employee ee) {
		// TODO Auto-generated constructor stub
		this.setBadges(ee.getBadges());
		this.setDob(ee.getDob());
		this.setEmail(ee.getEmail());
		
		this.setName(ee.getName());
		this.setPassword(ee.getPassword());
		this.setPhone_Number(ee.getPhone_Number());
		if(ee.getRanking()==null)
			this.setRanking(0);
		
		this.setRanking(ee.getRanking());
		
		
		List<Course> cl=ee.getCourses();
		List<CourseEntity> cel=null;
		if(cl!=null)
		{
			cel=new ArrayList<CourseEntity>();
			for (Course c : cl) {
				CourseEntity ce=new CourseEntity(c);
				cel.add(ce);
				
			}
		}
		this.setCourses(cel);
	}
	


}

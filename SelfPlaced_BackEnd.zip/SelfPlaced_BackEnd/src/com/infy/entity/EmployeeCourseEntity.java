package com.infy.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.infy.model.EmployeeCourse;

@Entity
@Table(name ="EmployeeCourse")
@GenericGenerator(name = "pkgen", strategy = "increment")	
public class EmployeeCourseEntity
{
	@Id
	@GeneratedValue(generator = "pkgen")
	private Integer empcouid;
	public Integer getEmpcouid() {
		return empcouid;
	}
	public void setEmpcouid(Integer empcouid) {
		this.empcouid = empcouid;
	}

	private Integer courseid;
	private Integer empid;
	private String status;
	private Integer trails;
	private Float max_Score;
	
	public Integer getTrails() {
		return trails;
	}
	public void setTrails(Integer trails) {
		this.trails = trails;
	}
	public Float getMax_Score() {
		return max_Score;
	}
	public void setMax_Score(Float max_Score) {
		this.max_Score = max_Score;
	}
	
	public Integer getCourseid() {
		return courseid;
	}
	public void setCourseid(Integer courseid) {
		this.courseid = courseid;
	}
	public Integer getEmpid() {
		return empid;
	}
	public void setEmpid(Integer empid) {
		this.empid = empid;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public EmployeeCourseEntity(){
		
		this.setStatus("started");
		this.setTrails(0);
		this.setMax_Score(0.0f);
		
	}
	
	public EmployeeCourseEntity(EmployeeCourse employeeCourse)
	{
		this.setCourseid(employeeCourse.getCourseid());
		this.setEmpid(employeeCourse.getEmpid());
		this.setStatus(employeeCourse.getStatus());
		this.setTrails(employeeCourse.getTrails());
		this.setMax_Score(employeeCourse.getMax_Score());
	
		
	}
}

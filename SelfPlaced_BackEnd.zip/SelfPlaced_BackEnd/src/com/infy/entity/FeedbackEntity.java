package com.infy.entity;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.infy.model.Feedback;

@Entity
@Table(name="Feedback")
@GenericGenerator(name = "pkgen", strategy = "increment")	
public class FeedbackEntity {

private String reviews;
	
	private Integer empid;
	private Integer courseid;
	@Id
	@GeneratedValue(generator = "pkgen")
	private Integer feedbackid;
	public String getReviews() {
		return reviews;
	}
	public void setReviews(String reviews) {
		this.reviews = reviews;
	}
	public Integer getEmpid() {
		return empid;
	}
	public void setEmpid(Integer empid) {
		this.empid = empid;
	}
	public Integer getCourseid() {
		return courseid;
	}
	public void setCourseid(Integer courseid) {
		this.courseid = courseid;
	}
	public Integer getFeedbackid() {
		return feedbackid;
	}
	public void setFeedbackid(Integer feedbackid) {
		this.feedbackid = feedbackid;
	}

	
	public FeedbackEntity() {
		// TODO Auto-generated constructor stub
	}
	
	
	public FeedbackEntity(Feedback fe) {
		// TODO Auto-generated constructor stub
		
		
		this.setCourseid(fe.getCourseid());
		this.setEmpid(fe.getEmpid());
		
		this.setReviews(fe.getReviews());
	}
	
}

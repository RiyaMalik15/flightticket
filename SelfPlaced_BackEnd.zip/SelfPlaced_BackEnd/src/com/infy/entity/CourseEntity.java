package com.infy.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.infy.model.Course;

@Entity
@Table(name = "Course")
public class CourseEntity {
	
	@Id
	private Integer courseid;
	
	private Integer no_Of_Enroll;
	private Integer duration;
	private String course_Name;
	private String description;
	
	public Integer getCourseid() {
		return courseid;
	}
	public void setCourseid(Integer courseid) {
		this.courseid = courseid;
	}
	public Integer getNo_Of_Enroll() {
		return no_Of_Enroll;
	}
	public void setNo_Of_Enroll(Integer no_Of_Enroll) {
		this.no_Of_Enroll = no_Of_Enroll;
	}
	public Integer getDuration() {
		return duration;
	}
	public void setDuration(Integer duration) {
		this.duration = duration;
	}
	public String getCourse_Name() {
		return course_Name;
	}
	public void setCourse_Name(String course_Name) {
		this.course_Name = course_Name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public CourseEntity() {
		// TODO Auto-generated constructor stub
	}
	
	public CourseEntity(Course ce) {
		this.setCourse_Name(ce.getCourse_Name());
		this.setCourseid(ce.getCourseid());
		this.setDescription(ce.getDescription());
		this.setDuration(ce.getDuration());
		this.setNo_Of_Enroll(ce.getNo_Of_Enroll());
		
	}
	

}

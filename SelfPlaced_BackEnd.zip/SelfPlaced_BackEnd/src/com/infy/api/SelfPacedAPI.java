package com.infy.api;


import java.util.ArrayList;
import java.util.List;

import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infy.model.Course;
import com.infy.model.Employee;
import com.infy.model.EmployeeCourse;
import com.infy.model.Feedback;
import com.infy.model.Question_Bank;
import com.infy.service.SelfPacedService;
import com.infy.service.SelfPacedServiceImpl;
import com.infy.utility.ContextFactory;

@RestController
@CrossOrigin
@RequestMapping("SelfPaced")
public class SelfPacedAPI 
{
	
	static SelfPacedService service=ContextFactory.getContext().getBean(SelfPacedServiceImpl.class);; 
	static Environment en=ContextFactory.getContext().getEnvironment();
	
			
	@PostMapping("addEmployee")
	public ResponseEntity<Employee> addEmployee(@RequestBody Employee employee)
	{
		
		ResponseEntity<Employee> responseEntity=null;

		Integer empId=null;
		
		try{
			empId=service.addEmployee(employee);
			employee.setEmpid(empId);
			responseEntity =new ResponseEntity<>(employee,HttpStatus.OK);
		}
		catch(Exception e)
		{
			
			String error = en.getProperty(e.getMessage());
			Employee emp = new Employee();
			emp.setMessage(error);
			responseEntity = new ResponseEntity<Employee>(emp,HttpStatus.BAD_REQUEST);
			
		}
		return responseEntity;
		
	}
	
	
	@PostMapping("loginEmployee")
	public ResponseEntity<Employee> loginEmployee(@RequestBody Employee employee)
	{
		ResponseEntity<Employee> responseEntity=null;

		Employee emp = null;
		
		try{
			emp=service.loginEmployee(employee);
			
			responseEntity =new ResponseEntity<>(emp,HttpStatus.OK);
		}
		catch(Exception e)
		{
			String error = en.getProperty(e.getMessage());
			 emp = new Employee();
			emp.setMessage(error);
			responseEntity = new ResponseEntity<>(emp,HttpStatus.BAD_REQUEST);
			
		}
		return responseEntity;
		
	}

	
	@PostMapping("addFeedback")
	public ResponseEntity<Feedback> addFeedback(@RequestBody Feedback feedback)
	{
		ResponseEntity<Feedback> responseEntity=null;

		Integer feedId=null;
		
		try{
			feedId=service.addFeedback(feedback);
			feedback.setFeedbackid(feedId);
			responseEntity =new ResponseEntity<>(feedback,HttpStatus.OK);
		}
		catch(Exception e)
		{
			String error = en.getProperty(e.getMessage());
			Feedback feed = new Feedback();
			feed.setMessage(error);
			responseEntity = new ResponseEntity<>(feed,HttpStatus.BAD_REQUEST);
			
		}
		return responseEntity;
		
	}
	
	
	@GetMapping("courseAllocation/{courseid}/{empid}")
	public ResponseEntity<Course> courseAllocation(@PathVariable("courseid") Integer courseid,@PathVariable("empid") Integer empid)
	{
		
		ResponseEntity<Course> responseEntity=null;

		Course c=null;
		
		try{
			c=service.courseAllocation(courseid,empid);
			
			responseEntity =new ResponseEntity<>(c,HttpStatus.OK);
		}
		catch(Exception e)
		{
			String error = en.getProperty(e.getMessage());
			c = new Course();
			c.setMessage(error);
			responseEntity = new ResponseEntity<>(c,HttpStatus.BAD_REQUEST);
			
		}
		return responseEntity;
		
	}
	
	
	@GetMapping("calculateBadge/{empid}")
	public ResponseEntity<?> calculateBadge(@PathVariable("empid") Integer empid)
	{
		ResponseEntity<?> res=null;
		try{
			Integer badge=service.calculateBadge(empid);
			res=new ResponseEntity<>(badge,HttpStatus.OK);
		}
		catch(Exception e)
		{
			String error = en.getProperty(e.getMessage());
			
			
			res = new ResponseEntity<>(error,HttpStatus.BAD_REQUEST);
			
		}
		return res;
	}

	@GetMapping("getEmployeeById/{empid}")
	public ResponseEntity<Employee> getEmployeeById(@PathVariable("empid") Integer empid)
	{
		ResponseEntity<Employee> res=null;
		Employee emp=null;
		try{
			emp=service.getEmployeeById(empid);
			res=new ResponseEntity<>(emp,HttpStatus.OK);
		}
		catch(Exception e)
		{
			String error = en.getProperty(e.getMessage());
			emp=new Employee();
			emp.setMessage(error);
			res = new ResponseEntity<>(emp,HttpStatus.BAD_REQUEST);
			
		}
		return res;
	}
	
	@PostMapping("check_details")
	public ResponseEntity<Employee> check_details(@RequestBody Employee employee)
	{
		ResponseEntity<Employee> res=null;
		Employee emp=null;
		try{
			emp=service.check_details(employee);
			res=new ResponseEntity<>(emp,HttpStatus.OK);
		}
		catch(Exception e)
		{
			String error = en.getProperty(e.getMessage());
			emp=new Employee();
			emp.setMessage(error);
			res = new ResponseEntity<>(emp,HttpStatus.BAD_REQUEST);
			
		}
		return res;
		
	}
	
	@PostMapping("change_password")
	public ResponseEntity<String> change_password(@RequestBody Employee employee) {
		
		ResponseEntity<String> res=null;
		try{
			String msg=service.change_password(employee.getEmpid(), employee.getPassword());
			res=new ResponseEntity<>(msg,HttpStatus.OK);
		}
		catch(Exception e)
		{
			String error = en.getProperty(e.getMessage());
			
			
			res = new ResponseEntity<>(error,HttpStatus.BAD_REQUEST);
			
		}
		return res;
	}
	
	@PostMapping("updateEmployee")
	public ResponseEntity<Employee> updateEmployee(@RequestBody Employee employee)
	{
		
		ResponseEntity<Employee> res=null;
		Employee emp=null;
		try{
			emp=service.updateEmployee(employee);
			res=new ResponseEntity<>(emp,HttpStatus.OK);
		}
		catch(Exception e)
		{
			String error = en.getProperty(e.getMessage());
			emp=new Employee();
			emp.setMessage(error);
			res = new ResponseEntity<>(emp,HttpStatus.BAD_REQUEST);
			
		}
		return res;
		
	}
	
	
	@GetMapping("getallEmployees")
	public ResponseEntity<List<Employee>> getallEmployees()
	{
		ResponseEntity<List<Employee>> res=null;
		List<Employee> emp=null;
		Employee employee=null;
		try{
			emp=service.getallEmployees();
			res=new ResponseEntity<>(emp,HttpStatus.OK);
		}
		catch(Exception e)
		{
			String error = en.getProperty(e.getMessage());
			employee=new Employee();
			employee.setMessage(error);
			emp=new ArrayList<Employee>();
			emp.add(employee);
			res = new ResponseEntity<>(emp,HttpStatus.BAD_REQUEST);
			
		}
		return res;
		
	}
	
	
	@GetMapping("getallFeedbacks")
	public ResponseEntity<List<Feedback>> getallFeedbacks()
	{
		ResponseEntity<List<Feedback>> res=null;
		List<Feedback> feed=null;
		Feedback feedback=null;
		try{
			feed=service.getallFeedbacks();
			res=new ResponseEntity<>(feed,HttpStatus.OK);
		}
		catch(Exception e)
		{
			String error = en.getProperty(e.getMessage());
			feedback=new Feedback();
			feedback.setMessage(error);
			feed=new ArrayList<Feedback>();
			feed.add(feedback);
			res = new ResponseEntity<>(feed,HttpStatus.BAD_REQUEST);
			
		}
		return res;
		
	}
	
	
	@GetMapping("getCourseById/{courseid}")
	public ResponseEntity<Course> getCourseById(@PathVariable("courseid") Integer courseid)
	{
		
		ResponseEntity<Course> res=null;
		Course course=null;
		try{
			course=service.getCourseById(courseid);
			
			res=new ResponseEntity<>(course,HttpStatus.OK);
		}
		catch(Exception e)
		{
			String error = en.getProperty(e.getMessage());
			course=new Course();
			course.setMessage(error);
			res = new ResponseEntity<>(course,HttpStatus.BAD_REQUEST);
			
		}
		return res;
	}
	
	
	
	@GetMapping("getallCourses")
	public ResponseEntity<List<Course>> getallCourses()
	{
		ResponseEntity<List<Course>> res=null;
		List<Course> cou=null;
		Course course=null;
		try{
			cou=service.getallCourses();
			res=new ResponseEntity<>(cou,HttpStatus.OK);
		}
		catch(Exception e)
		{
			String error = en.getProperty(e.getMessage());
			course=new Course();
			course.setMessage(error);
			cou=new ArrayList<Course>();
			cou.add(course);
			res = new ResponseEntity<>(cou,HttpStatus.BAD_REQUEST);
			
		}
		return res;
		
	}
	
	
	
	@GetMapping("getQuestionsByCourseId/{courseid}")
	public ResponseEntity<List<Question_Bank>> getQuestionsByCourseId(@PathVariable("courseid") Integer courseid)
	{
		
		ResponseEntity<List<Question_Bank>> res=null;
		List<Question_Bank> qbl=null;
		Question_Bank qb=null;
		try{
			qbl=service.getQuestionsByCourseId(courseid);
			res=new ResponseEntity<>(qbl,HttpStatus.OK);
		}
		catch(Exception e)
		{
			String error = en.getProperty(e.getMessage());
			qb=new Question_Bank();
			qb.setMessage(error);
			qbl=new ArrayList<Question_Bank>();
			qbl.add(qb);
			res = new ResponseEntity<>(qbl,HttpStatus.BAD_REQUEST);
			
		}
		return res;
		
	}
	
	@PostMapping("completeCourse")
	public ResponseEntity<EmployeeCourse> completeCourse(@RequestBody EmployeeCourse employeeCourse)
	{

		ResponseEntity<EmployeeCourse> res=null;
		EmployeeCourse emp=null;
		try{
			emp=service.completeCourse(employeeCourse);
			res=new ResponseEntity<>(emp,HttpStatus.OK);
		}
		catch(Exception e)
		{
		
			String error = en.getProperty(e.getMessage());
			emp=new EmployeeCourse();

			res = new ResponseEntity<>(emp,HttpStatus.BAD_REQUEST);
			
		}
		return res;
		
	}
	
	
	@GetMapping("getCompletedCourses/{empid}")
	public ResponseEntity<List<Course>> getCompletedCourses(@PathVariable("empid") Integer empid)
	{
		System.out.println("lohhh");
		ResponseEntity<List<Course>> res=null;
		List<Course> cou=null;
		Course course=null;
		try{
			cou=service.getCompletedCourses(empid);
			res=new ResponseEntity<>(cou,HttpStatus.OK);
		}
		catch(Exception e)
		{
			String error = en.getProperty(e.getMessage());
			course=new Course();
			course.setMessage(error);
			cou=new ArrayList<Course>();
			cou.add(course);
			res = new ResponseEntity<>(cou,HttpStatus.BAD_REQUEST);
			
		}
		return res;
		
	}
	
	
	
	@GetMapping("generateCertificate/{empid}/{courseid}")
	public ResponseEntity<Course> generateCertificate(@PathVariable("courseid") Integer courseid,@PathVariable("empid") Integer empid)
	{
		
		ResponseEntity<Course> responseEntity=null;
		Course c=new Course();
		String url=null;
		
		try{
			url=service.generateCertificate(courseid, empid);
			c.setMessage(url);
			responseEntity =new ResponseEntity<>(c,HttpStatus.OK);
		}
		catch(Exception e)
		{
			String error = en.getProperty(e.getMessage());
			c.setMessage(error);
			responseEntity = new ResponseEntity<>(c,HttpStatus.BAD_REQUEST);
			
		}
		return responseEntity;
		
	}
	
}





































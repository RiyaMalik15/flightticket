package com.infy.model;

import com.infy.entity.FeedbackEntity;

public class Feedback {
	private String reviews;
	
	private Integer empid;
	private Integer courseid;
	private Integer feedbackid;
	public String getReviews() {
		return reviews;
	}
	public void setReviews(String reviews) {
		this.reviews = reviews;
	}
	public Integer getEmpid() {
		return empid;
	}
	public void setEmpid(Integer empid) {
		this.empid = empid;
	}
	public Integer getCourseid() {
		return courseid;
	}
	public void setCourseid(Integer courseid) {
		this.courseid = courseid;
	}
	public Integer getFeedbackid() {
		return feedbackid;
	}
	public void setFeedbackid(Integer feedbackid) {
		this.feedbackid = feedbackid;
	}
	
	
	public Feedback() {
		// TODO Auto-generated constructor stub
	}

	public Feedback(FeedbackEntity fe) {
		
		this.setCourseid(fe.getCourseid());
		this.setEmpid(fe.getEmpid());
		this.setFeedbackid(fe.getFeedbackid());
		this.setReviews(fe.getReviews());
		
	}
	
private String message;
	
	
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

}

package com.infy.model;

import com.infy.entity.EmployeeCourseEntity;


public class EmployeeCourse 
{
	private Integer courseid;
	private Integer empid;
	private String status;
	private Integer trails;
	private Float max_Score;
	private Integer empcouid;
	
	public Integer getEmpcouid() {
		return empcouid;
	}
	
	public void setEmpcouid(Integer empcouid) {
		this.empcouid = empcouid;
	}

	public Integer getTrails() {
		return trails;
	}
	public void setTrails(Integer trails) {
		this.trails = trails;
	}
	public Float getMax_Score() {
		return max_Score;
	}
	public void setMax_Score(Float max_Score) {
		this.max_Score = max_Score;
	}
	public Integer getCourseid() {
		return courseid;
	}
	public void setCourseid(Integer courseid) {
		this.courseid = courseid;
	}
	public Integer getEmpid() {
		return empid;
	}
	public void setEmpid(Integer empid) {
		this.empid = empid;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public EmployeeCourse(){}
	public EmployeeCourse(EmployeeCourseEntity employeeCourseEntity)
	{
		this.setCourseid(employeeCourseEntity.getCourseid());
		this.setEmpid(employeeCourseEntity.getEmpid());
		this.setStatus(employeeCourseEntity.getStatus());
		this.setTrails(employeeCourseEntity.getTrails());
		this.setMax_Score(employeeCourseEntity.getMax_Score());
		this.setEmpcouid(employeeCourseEntity.getEmpcouid());
		
	}
	
	
}

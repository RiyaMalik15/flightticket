package com.infy.model;

import com.infy.entity.CourseEntity;

public class Course {
	
	
	private Integer courseid;
	private Integer no_Of_Enroll;
	private Integer duration;
	private String course_Name;
	private String description;
	private String message;
	
	
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Integer getCourseid() {
		return courseid;
	}
	public void setCourseid(Integer courseid) {
		this.courseid = courseid;
	}
	public Integer getNo_Of_Enroll() {
		return no_Of_Enroll;
	}
	public void setNo_Of_Enroll(Integer no_Of_Enroll) {
		this.no_Of_Enroll = no_Of_Enroll;
	}
	public Integer getDuration() {
		return duration;
	}
	public void setDuration(Integer duration) {
		this.duration = duration;
	}
	public String getCourse_Name() {
		return course_Name;
	}
	public void setCourse_Name(String course_Name) {
		this.course_Name = course_Name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public Course() {
		// TODO Auto-generated constructor stub
	}

	public Course(CourseEntity ce) {
		this.setCourse_Name(ce.getCourse_Name());
		this.setCourseid(ce.getCourseid());
		this.setDescription(ce.getDescription());
		this.setDuration(ce.getDuration());
		this.setNo_Of_Enroll(ce.getNo_Of_Enroll());
	}
	
	
	
	
	

}

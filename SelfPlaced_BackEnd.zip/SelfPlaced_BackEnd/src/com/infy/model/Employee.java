package com.infy.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.infy.entity.CourseEntity;
import com.infy.entity.EmployeeEntity;

public class Employee {
	private Integer empid;
	private String name;
	private LocalDate dob;
	private String password;
	private String email;
	
	private Integer ranking;
	private Integer badges;
	
	private Long phone_Number;

	private List<Course> courses; 

	
	
	public List<Course> getCourses() {
		return courses;
	}
	public void setCourses(List<Course> courses) {
		this.courses = courses;
	}
	public Integer getEmpid() {
		return empid;
	}
	public void setEmpid(Integer empid) {
		this.empid = empid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public LocalDate getDob() {
		return dob;
	}
	public void setDob(LocalDate dob) {
		this.dob = dob;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	public Integer getRanking() {
		return ranking;
	}
	public void setRanking(Integer ranking) {
		this.ranking = ranking;
	}
	public Integer getBadges() {
		return badges;
	}
	public void setBadges(Integer badges) {
		this.badges = badges;
	}

	public Long getPhone_Number() {
		return phone_Number;
	}
	public void setPhone_Number(Long phone_Number) {
		this.phone_Number = phone_Number;
	}
	

	
	
	public Employee() {
		// TODO Auto-generated constructor stub
	}
	
	public Employee(EmployeeEntity ee) {
		
		this.setBadges(ee.getBadges());
		this.setDob(ee.getDob());
		this.setEmail(ee.getEmail());
		this.setEmpid(ee.getEmpid());
		this.setName(ee.getName());
		this.setPassword(ee.getPassword());
		this.setPhone_Number(ee.getPhone_Number());
		this.setRanking(ee.getRanking());
		List<CourseEntity> cel=ee.getCourses();
		List<Course> cl=null;
		
		if(cel!=null)
		{
			cl=new ArrayList<>();
			for (CourseEntity ce : cel) {
				Course c=new Course(ce);
				cl.add(c);
			}
			
		}
		this.setCourses(cl);
	}
	
	private String message;
	
	
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	
	
	
}

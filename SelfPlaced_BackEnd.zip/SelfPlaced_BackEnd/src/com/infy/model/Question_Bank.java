package com.infy.model;

import com.infy.entity.Question_BankEntity;

public class Question_Bank {
	
	private Integer question_Number;
	private String question;
	private String option_A;
	private String option_B;
	private String option_C;
	private String option_D;
	private String answer;
	private Integer courseid;
	
	public Integer getQuestion_Number() {
		return question_Number;
	}
	public void setQuestion_Number(Integer question_Number) {
		this.question_Number = question_Number;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getOption_A() {
		return option_A;
	}
	public void setOption_A(String option_A) {
		this.option_A = option_A;
	}
	public String getOption_B() {
		return option_B;
	}
	public void setOption_B(String option_B) {
		this.option_B = option_B;
	}
	public String getOption_C() {
		return option_C;
	}
	public void setOption_C(String option_C) {
		this.option_C = option_C;
	}
	public String getOption_D() {
		return option_D;
	}
	public void setOption_D(String option_D) {
		this.option_D = option_D;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public Integer getCourseid() {
		return courseid;
	}
	public void setCourseid(Integer courseid) {
		this.courseid = courseid;
	}
	
	
	
	public Question_Bank() {
		// TODO Auto-generated constructor stub
	}
	public Question_Bank(Question_BankEntity qe) {
		this.setAnswer(qe.getAnswer());
		this.setCourseid(qe.getCourseid());
		this.setOption_A(qe.getOption_A());
		this.setOption_B(qe.getOption_B());
		this.setOption_C(qe.getOption_C());
		this.setOption_D(qe.getOption_D());
		this.setQuestion(qe.getQuestion());
		this.setQuestion_Number(qe.getQuestion_Number());
	}
	
	
private String message;
	
	
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	
	

}

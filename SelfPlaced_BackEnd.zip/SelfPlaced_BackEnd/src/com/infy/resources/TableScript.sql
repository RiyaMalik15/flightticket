DROP TABLE EmpCourse;
DROP TABLE EmployeeCourse;
DROP TABLE Feedback;
DROP TABLE Course;

DROP TABLE EMPLOYEE;


CREATE TABLE EMPLOYEE(
empid Number(3) PRIMARY KEY,
name VARCHAR2(20) NOT NULL,
dob DATE,
password  VARCHAR2(500)  NOT NULL,
email  VARCHAR2(20)  unique NOT NULL,
ranking  Number(2),
badges  Number(2),
phone_Number Number(10)  NOT NULL
);


INSERT INTO EMPLOYEE VALUES(101, 'prateek', TO_DATE('12/01/2016', 'DD/MM/YYYY'),'05079DD8972F6FD171402147DDBE4B73','prateek@gmail.com',0,null,9889865243);

INSERT INTO EMPLOYEE VALUES(102, 'prateek', null,'05079DD8972F6FD171402147DDBE4B73','pratek@gmail.com',0,null,9879865243);






CREATE TABLE Course (
courseid NUMBER(4) primary key,
no_Of_Enroll NUMBER(2) not null,
course_Name VARCHAR2(25) not null,
description VARCHAR2(40) not null,
duration NUMBER(3) not null
);


INSERT INTO Course VALUES (1001, 0, 'JAVA', 'Course on JAVA basics', 2);
INSERT INTO Course VALUES (1002, 0, 'C++', 'Course on C/C++ basics', 2);
INSERT INTO Course VALUES (1003, 0, 'PYTHON', 'Course on PYTHON basics', 2);







CREATE TABLE Feedback (
empid NUMBER(3) not null REFERENCES EMPLOYEE(empid),
courseid NUMBER(4) NOT NULL REFERENCES Course(courseid),
feedbackid  NUMBER(5) primary key,
reviews VARCHAR2(50) NOT NULL
);

INSERT INTO Feedback VALUES(101, 1001, 10001, 'Excellent Course');


CREATE TABLE EmployeeCourse (
empcouid number(4) primary key ,
courseid NUMBER(4) references Course(courseid),
empid NUMBER(3) references EMPLOYEE(empid),
status varchar(10) default 'started',
trails number(3) default 0,
max_Score number(5,2) default 0
);



insert into EmployeeCourse(empcouid,courseid,empid) values(1,1001,101);
insert into EmployeeCourse(empcouid,courseid,empid) values(3,1002,101);



CREATE TABLE EmpCourse (
courseid NUMBER(4) references Course(courseid),
empid NUMBER(3) references EMPLOYEE(empid)

);


insert into EmpCourse(courseid,empid) values(1001,101);
insert into EmpCourse(courseid,empid) values(1002,101);





select * from empcourse;

Select * from EMPLOYEE;
Select * from Feedback;
Select * from Course;
Select * from EmployeeCourse;


delete from EmployeeCourse where empid=101 and courseid=1003




































drop table Question_Bank;



CREATE TABLE Question_Bank(
  question_Number NUMBER(5) PRIMARY KEY,
  question VARCHAR(1000) NOT NULL
  ,option_A VARCHAR(109) 
  ,option_B VARCHAR(93) 
  ,option_C VARCHAR(110) 
  ,option_D VARCHAR(95) 
  ,answer VARCHAR(1) NOT NULL
   ,course_Id NUMBER(5) NOT NULL
);

INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (1,'What is the range of short data type in Java?','-128 to 127','-32768 to 32767','-2147483648 to 2147483647','None of the mentioned','b',1001);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (10,'If an expression contains double, int, float, long, then the whole expression will be promoted into which of these data types?','long','int','double','float','c',1001);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (11,'Which of the following is not a segment of memory in java?','Stack Segment','Heap Segment','Code Segment','Register Segment','d',1001);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (12,'Which one of the following is a class loader?','Bootstrap','Compiler','Heap','Interpreter','a',1001);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (13,'Which of these methods return a smallest whole number greater than or equal to variable X?','double ceil(double X)','double floor(double X)','double max(double X)','double min(double X)','a',1001);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (14,'Which of the following classes can catch all exceptions which cannot be caught?','RuntimeException','Error','Exception','ParentException','b',1001);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (15,'Which of the following handles the exception when a catch is not used?','finally','throw handler','default handler','java run time system','c',1001);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (16,'What exception thrown by parseInt() method?','ArithmeticException','ClassNotFoundException','NullPointerException','NumberFormatException','d',1001);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (17,'Which of these exceptions will occur if we try to access the index of an array beyond its length?','ArithmeticException','ArrayException','ArrayIndexException','ArrayIndexOutOfBoundsException','d',1001);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (18,'Which of the following is the correct way of implementing an interface salary by class manager?','class manager extends salary {}','class manager implements salary {}','class manager imports salary {}','none of the mentioned','b',1001);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (19,'Which of the following is an incorrect statement about packages?','Interfaces specifies what class must do but not how it does','Interfaces are specified public if they are to be accessed by any code in the program','All variables in interface are implicitly final and static','All variables are static and methods are public if interface is defined pubic','d',1001);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (2,'1.	    class average {
2.	        public static void main(String args[])
3.	        {
4.	            double num[] = {5.5, 10.1, 11, 12.8, 56.9, 2.5};
5.	            double result;
6.	            result = 0;
7.	            for (int i = 0; i < 6; ++i) 
8.	                result = result + num[i];
9.		    System.out.print(result/6);
10.	 
11.	        } 
12.	    }','16.34','16.566666644','16.46666666666667','16.46666666666666','c',1001);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (20,'Which of these operators is used to allocate memory to array variable in Java?','malloc','alloc','new','new malloc','c',1001);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (21,'Which of these is an incorrect array declaration?','int arr[] = new int[5].','int [] arr = new int[5].','int arr[] = new int[5]','int arr[] = int [5] new','d',1001);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (22,'int arr[] = new int [5];
    System.out.print(arr);','0','value stored in arr[0]','00000','Class name@ hashcode in hexadecimal form','d',1001);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (23,'Literal can be of which of these data types?','integer','float','boolean','all of the mentioned','d',1001);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (24,'What is true about private constructor?','Private constructor ensures only one instance of a class exist at any point of time','Private constructor ensures multiple instances of a class exist at any point of time','Private constructor eases the instantiation of a class','Private constructor allows creating objects in other classes','a',1001);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (26,'What is the size of char in C++?','2','4','2 or 4','based on the number of bits in the system','a',1002);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (27,'Which data type is used to represent the absence of parameters?','int','short','void','float','c',1002);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (28,'For what values of the expression is an if-statement block not executed?','0 and all negative values','0 and -1','0','0, all negative values, all positive values except 1','c',1002);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (29,'What is the output of this program?

    #include <iostream>
    using namespace std;
    enum colour {
        green, red, blue, white, yellow, pink
    };
    int main()
    {
        cout << green<< red<< blue<< white<< yellow<< pink;
        return 0;
    }','012345','123456','compile time error','runtime error','a',1002);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (3,'Which of this statement is incorrect?','switch statement is more efficient than a set of nested ifs','two case constants in the same switch can have identical values','switch statement can only test for equality, whereas if statement can evaluate any type of boolean expression','it is possible to create a nested switch statements','b',1001);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (30,'. What is the output of this program?

    #include <iostream>
    using namespace std;
    int main()
    {
        char arr[20];
        int i;
        for(i = 0; i < 10; i++)
            *(arr + i) = 65 + i;
        *(arr + i) = ''\0'';
        cout << arr;
        return(0);
    }','ABCDEFGHIJ','AAAAAAAAAA','JJJJJJJJ','None of the mentioned','a',1002);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (31,'. What is the output of this program?

   #include <iostream>
   using namespace std;
   int main ()
   {
       int numbers[5];
       int * p;
       p = numbers;  *p = 10;
       p++;  *p = 20;
       p = &numbers[2];  *p = 30;
       p = numbers + 3;  *p = 40;
       p = numbers;  *(p + 4) = 50;
       for (int n = 0; n < 5; n++)
           cout << numbers[n] << ",";
       return 0;
   }','10,20,30,40,50,','1020304050','compile error','runtime error','a',1002);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (32,'In which of the following we cannot overload the function?','return function','caller','called function','none of the mentioned','a',1002);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (34,'Which method do we use to append more than one character at a time?','append','operator+=','data','both append & operator+=','d',1002);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (35,'. What is the output of this program?

    #include <iostream>
    using namespace std;
    class p 
    {
        protected:
        int width, height;
        public:
        void set_values (int a, int b)
        {
            width = a; height = b; 
        }
        virtual int area (void) = 0;
    };
    class r: public p
    {
        public:
        int area (void)
        { 
            return (width * height);
        }
    };
    class t: public p 
    {
        public:
        int area (void)
        {
            return (width * height / 2); 
        }
    };
    int main () 
    {
        r rect;
        t trgl;
        p * ppoly1 = &rect;
        p * ppoly2 = &trgl;
        ppoly1->set_values (4, 5);
        ppoly2->set_values (4, 5);
        cout << ppoly1 -> area() ;
        cout << ppoly2 -> area();
        return 0;
    }','1020','20','10','2010','d',1002);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (36,'. What is meant by pure virtual function?','Function which does not have definition of its own','Function which does have definition of its own','Function which does not have any return type','None of the mentioned','a',1002);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (37,'What is the range of the floating point numbers?','-3.4E+38 to +3.4E+38','-3.4E+38 to +3.4E+34','-3.4E+38 to +3.4E+36','-3.4E+38 to +3.4E+32','a',1002);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (38,'Pick out the correct statement','Pre Increment is faster than post-increment','post-increment is faster than Pre Increment','pre increment is slower than post-increment','none of the mentioned','a',1002);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (39,'Where does the execution of the program starts?','user-defined function','main function','void function','none of the mentioned','b',1002);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (4,'When Overloading does not occur?','More than one method with same name but different method signature and different number or type of parameters','More than one method with same name, same signature but different number of signature','More than one method with same name, same signature, same number of parameters but different type','More than one method with same name, same number of parameters and type but different signature','d',1001);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (40,'What are mandatory parts in the function declaration?','return type, function name','return type, function name, parameters','parameters, function name','none of the mentioned','a',1002);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (41,'Where does the return statement returns the execution of the program?','main function','caller function','same function','none of the mentioned','b',1002);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (42,'To which does the function pointer point to?','variable','constants','function','absolute variables','c',1002);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (43,'____ have the return type void?','all functions','constructors','destructors','none of the mentioned','d',1002);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (44,'Which of the following gives the memory address of the first element in array?','array[0];','array[1];','array(2);','array;','d',1002);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (45,'Which is used to define the member of a class externally?',':','::','#','none of the mentioned','b',1002);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (46,'What is this operator called ?:?','conditional','relational','casting operator','none of the mentioned','a',1002);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (47,'The if..else statement can be replaced by which operator?','Bitwise operator','Conditional operator','Multiplicative operator','None of the mentioned','b',1002);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (48,'Identify the incorrect option.','1 <= sizeof(bool) <= sizeof(long)','sizeof(float) <= sizeof(double) <= sizeof(long double)','sizeof(char) <= sizeof(long) <=sizeof(wchar_t)','sizeof(N) = sizeof(signed N) = sizeof(unsigned N)','c',1002);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (49,'What is the output of the following code? 1.	    #include <iostream>
2.	    using namespace std;
3.	    int main()
4.	    {
5.	        int a = 5;
6.	        float b;
7.	        cout << sizeof(++a + b);
8.	        cout << a;
9.	        return 0;
10.	    }','2 6','4 6','2 5','4 5','d',1002);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (5,'What is it called where object has its own lifecycle and child object cannot belong to another parent object?','Aggregation','Composition','Encapsulation','Association','a',1001);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (50,'Which of these following members are not accessed by using direct member access operator?','public','private','protected','both private & protected','d',1002);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (51,'What is the output of the following?

i = 0
while i < 5:
    print(i)
    i += 1
    if i == 3:
        break
else:
    print(0)','0 1 2 0','0 1 2','error','none of the above mentioned','b',1003);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (52,'What is the output of the following?

x = "abcdef"
i = "i"
while i in x:
    print(i, end=" ")','no output','i i i i i i a�','a b c d e f','abcdef','a',1003);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (53,'What is the output of the following?

print("xyyzxyzxzxyy".count(''yy''))','2','0','error','none of the mentioned','a',1003);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (54,'What will be the output?

>>>m = [[x, x + 1, x + 2] for x in range(0, 3)]','[[1, 2, 3], [4, 5, 6], [7, 8, 9]]','[[0, 1, 2], [1, 2, 3], [2, 3, 4]].','[1, 2, 3, 4, 5, 6, 7, 8, 9].','[0, 1, 2, 1, 2, 3, 2, 3, 4].','b',1003);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (55,'What is the output of the following code?

    c.test=c.test+1
    k=k+1
class A:
    def __init__(self):
        self.test = 0
def main():
    Count=A()
    k=0
 
    for i in range(0,25):
        add(Count,k)
    print("Count.test=", Count.test)
    print("k =", k)
main()','Exception is thrown','Count.test=25
k=25','Count.test=25
k=0','Count.test=0
k=0','c',1003);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (58,'Which of these is a private data field?

def Demo:
def __init__(self):
    __a = 1
    self.__b = 1
    self.__c__ = 1
    __d__= 1','__a','__b','__c__','__d__','b',1003);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (59,'What is the output of the code shown below?

x=10
y=8
assert x>y, ''X too small''','Assertion Error','10 8','No output','108','c',1003);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (6,'If a class inheriting an abstract class does not define all of its function then it will be known as?','Abstract','A  simple	class','Static	class','None of the mentioned','a',1001);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (60,'Which is the correct operator for power(xy)?','X^y','X**y','X^^y','None of the mentioned','b',1003);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (61,'Which one of the following have the same precedence?','Addition and Subtraction','Multiplication and Division','Both Addition and Subtraction AND Multiplication and Division','None of the mentioned','a',1003);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (64,'What is the output of the code shown below?

x=1
def cg():
	global x
	x=x+1	
cg()
x','2','1','0','error','a',1003);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (65,'What is the output of the code shown below?

e="butter"
def f(a): print(a)+e
f("bitter")','error','butter
error','bitter
error','bitterbutter','c',1003);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (66,'The output of the two codes shown below is the same. State whether true or false.

CODE 1
>>> re.split(r''(a)(t)'', ''The night sky'')
CODE 2
>>> re.split(r''\s+'', ''The night sky'')','true','false',NULL,NULL,'b',1003);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (67,'What is the output of the following piece of code?

class A:
    def test1(self):
        print(" test of A called ")
class B(A):
    def test(self):
        print(" test of B called ")
class C(A):
    def test(self):
        print(" test of C called ")
class D(B,C):
    def test2(self):
        print(" test of D called ")        
obj=D()
obj.test()','test of B called
test of C called','test of C called
test of B called','test of B called','Error, both the classes from which D derives has same method test()','c',1003);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (68,'Which function overloads the == operator?','__eq__()','__equ__()','__isequal__()','none of the mentioned','a',1003);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (69,'Let A and B be objects of class Foo. Which functions are called when print(A + B) is executed?','__add__(), __str__()','__str__(), __add__()','__sum__(), __str__()','__str__(), __sum__()','a',1003);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (7,'What would be the result if a class extends two interfaces and both have a method with same name and signature?','Runtime error','Compile time error','Code runs successfully','First called method is executed successfully','b',1001);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (70,'Which of the following is not the correct syntax for creating a set?','set([[1,2],[3,4]])','set([1,2,2,3,4])','set((1,2,3,4))','{1,2,3,4}','a',1003);

INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (72,'A class in which one or more methods are only implemented to raise an exception is called an abstract class. True or False?','true','false',NULL,NULL,'a',1003);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (73,'Overriding means changing behaviour of methods of derived class methods in the base class. Is the statement true or false?','true','false',NULL,NULL,'b',1003);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (74,'Which of these is false about recursion?','Recursive function can be replaced by a non-recursive function','Recursive functions usually take more memory space than non-recursive function','Recursive functions run faster than non-recursive function','Recursion makes programs easier to understand','c',1003);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (75,'What is the output of the following?

for i in range(10):
    if i == 5:
        break
    else:
        print(i)
else:
    print("Here")','0 1 2 3 4 Here','0 1 2 3 4 5 Here','0 1 2 3 4','1 2 3 4 5','c',1003);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (8,'1.	    class A 
2.	    {
3.	        int i;
4.	        void display() 
5.	        {
6.	            System.out.println(i);
7.	        }
8.	    }    
9.	    class B extends A 
10.	    {
11.	        int j;
12.	        void display() 
13.	        {
14.	            System.out.println(j);
15.	        }
16.	    }    
17.	    class method_overriding 
18.	    {
19.	        public static void main(String args[])
20.	        {
21.	            B obj = new B();
22.	            obj.i=1;
23.	            obj.j=2;   
24.	            obj.display();     
25.	        }
26.	   }','0','1','2','Compilation Error','c',1001);
INSERT INTO Question_Bank(question_Number,question,option_A,option_B,option_C,option_D,answer,course_Id) VALUES (9,'Which of these method of class String is used to extract a single character from a String object?','CHARAT()','chatat()','charAt()','ChatAt()','c',1001);



select * from Question_Bank;

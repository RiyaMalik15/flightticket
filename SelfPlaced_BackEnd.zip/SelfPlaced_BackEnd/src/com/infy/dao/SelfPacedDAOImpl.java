package com.infy.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;






import org.apache.jasper.tagplugins.jstl.core.ForEach;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.AES.Encrypt_Decrypt;
import com.infy.entity.CourseEntity;
import com.infy.entity.EmployeeCourseEntity;
import com.infy.entity.EmployeeEntity;
import com.infy.entity.FeedbackEntity;
import com.infy.entity.Question_BankEntity;
import com.infy.model.Course;
import com.infy.model.Employee;
import com.infy.model.EmployeeCourse;
import com.infy.model.Feedback;
import com.infy.model.Question_Bank;

@Repository(value = "DAO")
public class SelfPacedDAOImpl implements SelfPacedDAO {

	@Autowired
	SessionFactory sessionfactory;

	@Override
	public Integer addEmployee(Employee employee) throws Exception {
	
		Session session =sessionfactory.getCurrentSession();
		CriteriaBuilder builder=session.getCriteriaBuilder();
		CriteriaQuery<EmployeeCourseEntity> criteriaQuery= builder.createQuery(EmployeeCourseEntity.class);
		Root<EmployeeCourseEntity> root = criteriaQuery.from(EmployeeCourseEntity.class);
		criteriaQuery.select(root);
		criteriaQuery.where(builder.equal(root.get("email"), employee.getEmail()));

		EmployeeCourseEntity ece=session.createQuery(criteriaQuery).uniqueResult();
	
		if(ece!=null)
			return null;
		EmployeeEntity ee=new EmployeeEntity(employee);
		return (Integer) session.save(ee);
	}	

	@Override
	public Integer addFeedback(Feedback feedback) throws Exception {
		Session session =sessionfactory.getCurrentSession();
		FeedbackEntity fe=new FeedbackEntity(feedback);
		return (Integer) session.save(fe);
	}

	@Override
	public Course courseAllocation(Integer courseid,Integer empid)
			throws Exception {
		
		
		Session session =sessionfactory.getCurrentSession();
		
		CriteriaBuilder builder=session.getCriteriaBuilder();
		CriteriaQuery<EmployeeCourseEntity> criteriaQuery= builder.createQuery(EmployeeCourseEntity.class);
		Root<EmployeeCourseEntity> root = criteriaQuery.from(EmployeeCourseEntity.class);
		criteriaQuery.select(root);
		criteriaQuery.where(builder.and(builder.equal(root.get("empid"), empid),builder.equal(root.get("courseid"), courseid)));

		EmployeeCourseEntity ece=session.createQuery(criteriaQuery).uniqueResult();
	
		if(ece!=null)
			{	
			return null;
			}	
		
		EmployeeCourseEntity employeeCourseEntity=new EmployeeCourseEntity();
		employeeCourseEntity.setCourseid(courseid);
		employeeCourseEntity.setEmpid(empid);
		session.save(employeeCourseEntity);
		
		
		EmployeeEntity ee=session.get(EmployeeEntity.class,empid);
		
	
		CourseEntity ce=session.get(CourseEntity.class, courseid);		
		Integer i=ce.getNo_Of_Enroll();
		if(i==null)
		{
			ce.setNo_Of_Enroll(1);
		}
		else ce.setNo_Of_Enroll(i+1);
		
		
		List<CourseEntity> cl=ee.getCourses();
		if(cl==null)
		{
			cl=new ArrayList<>();
			cl.add(ce);
		}
		else
			cl.add(ce);
		ee.setCourses(cl);
		return new Course(ce);
	}

	@Override
	public Integer calculateBadge(Integer empid) throws Exception {
		
		Session session=sessionfactory.getCurrentSession();
		CriteriaBuilder builder=session.getCriteriaBuilder();
		CriteriaQuery<EmployeeCourseEntity> criteriaQuery= builder.createQuery(EmployeeCourseEntity.class);
		Root<EmployeeCourseEntity> root = criteriaQuery.from(EmployeeCourseEntity.class);
		criteriaQuery.select(root);
		criteriaQuery.where(builder.and(builder.equal(root.get("empid"), empid),builder.equal(root.get("status"),"completed")));
		List<EmployeeCourseEntity> ece=session.createQuery(criteriaQuery).getResultList();
		
		
		EmployeeEntity ee=session.get(EmployeeEntity.class, empid);
		ee.setBadges(ece.size());
		return ece.size();

	}

	@Override
	public Employee loginEmployee(Employee employee) throws Exception {
		
		employee.setPassword(Encrypt_Decrypt.encrpytpass(employee.getPassword()));
		Session session = sessionfactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<EmployeeEntity> criteriaQuery= builder.createQuery(EmployeeEntity.class);
		
		Root<EmployeeEntity> root = criteriaQuery.from(EmployeeEntity.class);
		criteriaQuery.select(root);
		criteriaQuery.where(builder.and(builder.equal(root.get("email"), employee.getEmail()),builder.equal(root.get("password"), employee.getPassword())));
		EmployeeEntity ee=session.createQuery(criteriaQuery).uniqueResult();
		if(ee==null)
			return null;
		Employee e=new Employee(ee);
		return e;
		
		
	}

	@Override
	public Employee getEmployeeById(Integer empid) throws Exception {
		Session session=sessionfactory.getCurrentSession();
		EmployeeEntity ee=session.get(EmployeeEntity.class, empid);
		if(ee==null)
		{
			throw new Exception();
		}
		Employee e=new Employee(ee);
		return e;
	}

	@Override
	public Employee check_details(Employee employee) throws Exception {
		
		Session session = sessionfactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<EmployeeEntity> criteriaQuery= builder.createQuery(EmployeeEntity.class);
		
		Root<EmployeeEntity> root = criteriaQuery.from(EmployeeEntity.class);
		criteriaQuery.select(root);
		
		criteriaQuery.where(builder.and(builder.and(
				builder.equal(builder.upper(root.get("name")),employee.getName().toUpperCase()),
				builder.equal(root.get("email"), employee.getEmail())
													),
										builder.and(
				builder.equal(root.get("dob"),employee.getDob()),
				builder.equal(root.get("phone_Number"), employee.getPhone_Number())				
					
													)
									)
						);
		
		
		EmployeeEntity ee=session.createQuery(criteriaQuery).uniqueResult();
		if(ee==null)
		{
			
			throw new Exception();
		}
		return new Employee(ee);
		}

	@Override
	public String change_password(Integer empid, String password)
			throws Exception {
		
		Session session = sessionfactory.getCurrentSession();
		EmployeeEntity ee=session.get(EmployeeEntity.class,empid);
		if(ee==null)
		{
			throw new Exception();
		}
		ee.setPassword(password);
		session.save(ee);
		return "Password Changed Successfully";
		
		}

	@Override
	public Employee updateEmployee(Employee employee) throws Exception {
		
		
		Session session = sessionfactory.getCurrentSession();
		EmployeeEntity ee=session.get(EmployeeEntity.class,employee.getEmpid());
		if(ee==null)
		{
			throw new Exception();
		}
		ee.setDob(employee.getDob());
		ee.setName(employee.getName());
		ee.setPhone_Number(employee.getPhone_Number());
		session.save(ee);
		return new Employee(ee);
		
	}

	@Override
	public List<Employee> getallEmployees() throws Exception {
		
		Session session = sessionfactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<EmployeeEntity> criteriaQuery= builder.createQuery(EmployeeEntity.class);
		
		Root<EmployeeEntity> root = criteriaQuery.from(EmployeeEntity.class);
		criteriaQuery.select(root);
		
		List<Employee> le=new ArrayList<>();
		List<EmployeeEntity> ee=session.createQuery(criteriaQuery).getResultList();
		
		for (EmployeeEntity employeeEntity : ee) {
			
			Employee e=new Employee(employeeEntity);
			le.add(e);
		}
		
		return le;
		
	}

	@Override
	public List<Feedback> getallFeedbacks() throws Exception {
		
		
		
		Session session = sessionfactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<FeedbackEntity> criteriaQuery= builder.createQuery(FeedbackEntity.class);
		
		Root<FeedbackEntity> root = criteriaQuery.from(FeedbackEntity.class);
		criteriaQuery.select(root);
		
		List<Feedback> fl=new ArrayList<>();
		List<FeedbackEntity> ee=session.createQuery(criteriaQuery).getResultList();
		
		for (FeedbackEntity fee : ee) {
			
			Feedback feedback=new Feedback(fee);
			fl.add(feedback);
		}
		
		return fl;
	}

	@Override
	public Course getCourseById(Integer courseid) throws Exception {
		
		Session session = sessionfactory.getCurrentSession();
		CourseEntity ce =session.get(CourseEntity.class, courseid);
		if(ce==null)
		{
			return null;
		}
		else
		
			return new Course(ce);
		
		}

	@Override
	public List<Course> getallCourses() throws Exception {
		

		Session session = sessionfactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<CourseEntity> criteriaQuery= builder.createQuery(CourseEntity.class);
		
		Root<CourseEntity> root = criteriaQuery.from(CourseEntity.class);
		criteriaQuery.select(root);
		
		List<Course> cl=new ArrayList<>();
		List<CourseEntity> ee=session.createQuery(criteriaQuery).getResultList();
		
		for (CourseEntity cou : ee) {
			
			Course course=new Course(cou);
			cl.add(course);
		}
		
		return cl;
		
	}

	@Override
	public List<Question_Bank> getQuestionsByCourseId(Integer courseid)
			throws Exception {
		
		
		Session session = sessionfactory.getCurrentSession();
		
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<Question_BankEntity> criteriaQuery= builder.createQuery(Question_BankEntity.class);
		
		Root<Question_BankEntity> root = criteriaQuery.from(Question_BankEntity.class);
		criteriaQuery.where(builder.equal(root.get("courseid"), courseid));
		criteriaQuery.select(root);
		
		List<Question_Bank> ql=new ArrayList<>();
		List<Question_BankEntity> ee=session.createQuery(criteriaQuery).getResultList();
		
		Collections.shuffle(ee);
		
		for(int i=0;i<10;i++)
		{
			Question_Bank qb =new Question_Bank(ee.get(i));
			ql.add(qb);
			
		}
		return ql;
	}

	@Override
	public EmployeeCourse completeCourse(EmployeeCourse employeeCourse)  throws Exception{
		
		Session session =sessionfactory.getCurrentSession();
		CriteriaBuilder builder=session.getCriteriaBuilder();
		CriteriaQuery<EmployeeCourseEntity> criteriaQuery= builder.createQuery(EmployeeCourseEntity.class);
		Root<EmployeeCourseEntity> root = criteriaQuery.from(EmployeeCourseEntity.class);
		
		criteriaQuery.select(root);
		criteriaQuery.where(builder.and(builder.equal(root.get("empid"), employeeCourse.getEmpid()),builder.equal(root.get("courseid"), employeeCourse.getCourseid())));

		EmployeeCourseEntity ece=session.createQuery(criteriaQuery).uniqueResult();
		
		if(ece==null)
			{	
			return null;
			}	
		ece.setTrails(ece.getTrails()+1);
		
		if(employeeCourse.getMax_Score()<50)
		{
			session.save(ece);
			return new EmployeeCourse(ece);
		}
		ece.setStatus("completed");
	
		
		if(ece.getMax_Score()>=employeeCourse.getMax_Score())
		{
			session.save(ece);
			calculateBadge(employeeCourse.getEmpid());
			
		}
		else{
			
			
			ece.setMax_Score(employeeCourse.getMax_Score());
			session.save(ece);
			calculateBadge(employeeCourse.getEmpid());
		calculateRank(employeeCourse);
		}
		return new EmployeeCourse(ece);		
	}
	
	
	private void calculateRank(EmployeeCourse employeeCourse)
	{
		Session session =sessionfactory.getCurrentSession();
		CriteriaBuilder builder=session.getCriteriaBuilder();
		CriteriaQuery<Float> criteriaQuery= builder.createQuery(Float.class);
		Root<EmployeeCourseEntity> root = criteriaQuery.from(EmployeeCourseEntity.class);
		criteriaQuery.where(builder.equal(root.get("empid"),employeeCourse.getEmpid()));
		criteriaQuery.groupBy(root.get("empid"));
		criteriaQuery.select(builder.sum(root.get("max_Score")));
		Float total=session.createQuery(criteriaQuery).uniqueResult(); //to get total score of particular employee
		
		
	
		CriteriaBuilder builder2=session.getCriteriaBuilder();
		CriteriaQuery<Object[]> criteriaQuery2= builder2.createQuery(Object[].class);
		Root<EmployeeCourseEntity> root2 = criteriaQuery2.from(EmployeeCourseEntity.class);
		criteriaQuery2.where(builder2.notEqual(root2.get("empid"),employeeCourse.getEmpid()));
		criteriaQuery2.groupBy(root2.get("empid"));
		criteriaQuery2.multiselect(root2.get("empid"),builder2.sum(root2.get("max_Score")));
		List<Object[]> emplist=session.createQuery(criteriaQuery2).getResultList();  		//to get all employee with there total score except that employee
		
		
		Integer empid=gethighestEmployee(emplist, total);   // get empid where score is ge than max but lowest
		
		Integer rank;
		if(empid==0){
			rank=1;
		}
		else
		{
			EmployeeEntity ee=session.get(EmployeeEntity.class,empid);
			rank=ee.getRanking()+1;
		}
		
		
		setRank(employeeCourse.getEmpid(),rank);
	}
	
	
	private Integer gethighestEmployee(List<Object[]> emplist,Float score)
	{
		Integer empid=0;
		Float s= 1000f;
		Float obj;
		
		for (Object[] test : emplist) {
			
			obj=(Float)test[1];
			if(obj>score && obj<s)
			{
				s=obj;
				empid=(Integer)test[0];
			}
		}
		
		return empid;
	}
	
	private void setRank(Integer empid,Integer rank)
	{
		Session session = sessionfactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<EmployeeEntity> criteriaQuery= builder.createQuery(EmployeeEntity.class);
		
		Root<EmployeeEntity> root = criteriaQuery.from(EmployeeEntity.class);
		criteriaQuery.where(builder.greaterThanOrEqualTo(root.get("ranking"),rank));   //find all employee with the ranking gt rank
		criteriaQuery.select(root);
		
		List<Employee> le=new ArrayList<>();
		List<EmployeeEntity> ee=session.createQuery(criteriaQuery).getResultList();
		
		for (EmployeeEntity employeeEntity : ee) {
			
			employeeEntity.setRanking(employeeEntity.getRanking()+1);
			session.save(employeeEntity);									//setting rank to rank+1
		}
		
		
		EmployeeEntity empEntity=session.get(EmployeeEntity.class,empid);
		empEntity.setRanking(rank);	//saving rank for particular employee
		session.save(empEntity);
	}

	@Override
	public List<Course> getCompletedCourses(Integer empid) throws Exception {
		
		
		Session session=sessionfactory.getCurrentSession();
		CriteriaBuilder builder=session.getCriteriaBuilder();
		CriteriaQuery<EmployeeCourseEntity> criteriaQuery= builder.createQuery(EmployeeCourseEntity.class);
		Root<EmployeeCourseEntity> root = criteriaQuery.from(EmployeeCourseEntity.class);
		criteriaQuery.select(root);
		criteriaQuery.where(builder.and(builder.equal(root.get("empid"), empid),builder.equal(root.get("status"),"completed")));
		List<EmployeeCourseEntity> ece=session.createQuery(criteriaQuery).getResultList();
		
		
		List<Course> cl=new ArrayList<>();
		for (EmployeeCourseEntity employeeCourseEntity : ece) {
			
			Course c=getCourseById(employeeCourseEntity.getCourseid());
			cl.add(c);
		}
		
		
		return cl;
		
		
		
	}	
	
	}

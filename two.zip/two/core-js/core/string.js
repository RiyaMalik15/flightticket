require('../modules/core.string.escape-html');
require('../modules/core.string.unescape-html');
module.exports = require('../modules/_core').String;

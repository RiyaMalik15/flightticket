require('../../../modules/es6.array.slice');
module.exports = require('../../../modules/_entry-virtual')('Array').slice;

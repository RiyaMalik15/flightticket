require('../../modules/es6.array.index-of');
module.exports = require('../../modules/_core').Array.indexOf;

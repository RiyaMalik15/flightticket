require('../../modules/es7.object.values');
module.exports = require('../../modules/_core').Object.values;

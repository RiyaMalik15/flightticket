require('../../modules/es6.object.keys');
module.exports = require('../../modules/_core').Object.keys;

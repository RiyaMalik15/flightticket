require('../../modules/es6.number.is-safe-integer');
module.exports = require('../../modules/_core').Number.isSafeInteger;

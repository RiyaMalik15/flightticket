require('../../../modules/es6.number.to-fixed');
module.exports = require('../../../modules/_entry-virtual')('Number').toFixed;

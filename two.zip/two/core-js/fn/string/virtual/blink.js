require('../../../modules/es6.string.blink');
module.exports = require('../../../modules/_entry-virtual')('String').blink;

require('../../../modules/es6.string.italics');
module.exports = require('../../../modules/_entry-virtual')('String').italics;

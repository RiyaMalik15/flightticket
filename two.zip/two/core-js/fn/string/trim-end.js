require('../../modules/es7.string.trim-right');
module.exports = require('../../modules/_core').String.trimRight;

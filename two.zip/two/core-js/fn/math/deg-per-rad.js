require('../../modules/es7.math.deg-per-rad');
module.exports = Math.PI / 180;
